"""GameManager: orquesta todo el juego con jugabilidad mejorada."""

import random
import math
import pygame
import os
from datetime import datetime
from config import *
from entities import Prey, Predator, Food
from ai_controller import AIController
#from analytics import generate_reports
from analytics import AnalyticsDashboard
from utils import distancia_toroidal, save_web_data, load_web_data
from visual_effects import VisualManager
#import pandas as pd
import asyncio
import csv
from utils import distancia_toroidal, save_web_data, load_web_data

class MenuParticle:
    """Partícula decorativa para el menú principal."""
    def __init__(self, x, y, color, speed=20, size=2, lifetime=3.0):
        self.pos = [float(x), float(y)]
        angle = random.uniform(0, 2 * math.pi)
        self.vel = [math.cos(angle) * speed, math.sin(angle) * speed]
        self.color = color
        self.size = size
        self.lifetime = lifetime
        self.age = 0.0
        self.alive = True
        self.pulse_phase = random.uniform(0, 2 * math.pi)

    def update(self, dt):
        self.age += dt
        if self.age >= self.lifetime:
            self.alive = False
            return
        self.pos[0] += self.vel[0] * dt
        self.pos[1] += self.vel[1] * dt
        if self.pos[0] < 0 or self.pos[0] > WORLD_W:
            self.vel[0] *= -0.8
        if self.pos[1] < 0 or self.pos[1] > WORLD_H:
            self.vel[1] *= -0.8

    def draw(self, screen, time_elapsed):
        if not self.alive:
            return
        alpha = 1.0 - (self.age / self.lifetime)
        pulse = 1.0 + 0.3 * math.sin(time_elapsed * 3 + self.pulse_phase)
        size = max(1, int(self.size * alpha * pulse))
        color = tuple(int(c * alpha) for c in self.color)
        pygame.draw.circle(screen, color, (int(self.pos[0]), int(self.pos[1])), size)


class MenuButton:
    """Botón interactivo con efectos hover y glow."""
    def __init__(self, x, y, width, height, text, color, hover_color, text_color=(255,255,255), 
                 font_size=16, glow_color=None, border_radius=8):
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.color = color
        self.hover_color = hover_color
        self.text_color = text_color
        self.font = pygame.font.SysFont("Arial", font_size, bold=True)
        self.glow_color = glow_color or color
        self.border_radius = border_radius
        self.hovered = False
        self.pulse = 0.0
        self.selected = False

    def update(self, mouse_pos, dt):
        was_hovered = self.hovered
        self.hovered = self.rect.collidepoint(mouse_pos)
        if self.hovered:
            self.pulse = (self.pulse + dt * 4) % (2 * math.pi)
        else:
            self.pulse = 0

    def draw(self, screen):
        if self.hovered or self.selected:
            glow_alpha = 40 + int(20 * math.sin(self.pulse)) if self.hovered else 30
            glow_size = 6 if self.hovered else 4
            glow_rect = self.rect.inflate(glow_size * 2, glow_size * 2)
            glow_surface = pygame.Surface((glow_rect.width, glow_rect.height), pygame.SRCALPHA)
            glow_c = (*self.glow_color, glow_alpha)
            pygame.draw.rect(glow_surface, glow_c, 
                           (0, 0, glow_rect.width, glow_rect.height), 
                           border_radius=self.border_radius + 2)
            screen.blit(glow_surface, glow_rect.topleft)

        bg_color = self.hover_color if self.hovered else self.color
        if self.selected:
            bg_color = tuple(min(255, c + 30) for c in bg_color)

        pygame.draw.rect(screen, bg_color, self.rect, border_radius=self.border_radius)

        border_color = tuple(min(255, c + 50) for c in bg_color) if self.hovered or self.selected else (60, 70, 90)
        border_width = 2 if self.hovered or self.selected else 1
        pygame.draw.rect(screen, border_color, self.rect, border_width, border_radius=self.border_radius)

        text_surface = self.font.render(self.text, True, self.text_color)
        text_x = self.rect.centerx - text_surface.get_width() // 2
        text_y = self.rect.centery - text_surface.get_height() // 2
        screen.blit(text_surface, (text_x, text_y))

    def is_clicked(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            return self.rect.collidepoint(event.pos)
        return False


class GameManager:
    def __init__(self):
        pygame.mixer.pre_init(frequency=44100, size=-16, channels=2, buffer=4096)
        pygame.init()

        # NUEVO: Evento personalizado para fin de música
        self.SONG_END = pygame.USEREVENT + 1

        # NUEVO: Inicializar música antes de crear la ventana
        self._init_music()

        self.screen = pygame.display.set_mode((SCREEN_W, SCREEN_H))
        pygame.display.set_caption("ÁPEX: Instinto Artificial v3.0")
        self.clock = pygame.time.Clock()

        self.font = pygame.font.SysFont("Arial", 14)
        self.font_bold = pygame.font.SysFont("Arial", 14, bold=True)
        self.font_title = pygame.font.SysFont("Arial", 18, bold=True)
        self.font_big = pygame.font.SysFont("Arial", 28, bold=True)
        self.font_huge = pygame.font.SysFont("Arial", 42, bold=True)
        self.font_number = pygame.font.SysFont("Arial", 32, bold=True)
        self.font_record = pygame.font.SysFont("Arial", 20, bold=True)
        self.font_small = pygame.font.SysFont("Arial", 12)
        self.font_alert = pygame.font.SysFont("Arial", 16, bold=True)

        self.mode = "MENU"
        self.human_role = "PREY"
        self.num_preys = 30
        self.num_preds = 3

        self.ai_controller = AIController()
        self.visual_manager = VisualManager()
        self.dashboard = AnalyticsDashboard()

        self.food_list = []
        self.food_spawn_timer = 0.0

        self.best_time = 0.0
        self.best_captures = 0
        self.best_score = 0
        self._load_records()

        # NUEVO: Sistema de dificultad progresiva
        self.difficulty_level = 0
        self.difficulty_timer = 0.0
        self.difficulty_bonus = 0.0

        # NUEVO: Sistema de logros
        self.achievements_unlocked = set()
        self.achievement_queue = []
        self.achievement_timer = 0.0

        # NUEVO: Alertas de proximidad
        self.proximity_alert_cooldown = 0.0

        # NUEVO: Victoria por música
        self.music_victory = False

        # MENÚ
        self.menu_time = 0.0
        self.menu_particles = []
        self.menu_buttons = []
        self._init_menu_buttons()
        self.menu_role_anim = 0.0

        self.reset_game()

    def _init_menu_buttons(self):
        center_x = WORLD_W // 2
        start_y = 280
        btn_w, btn_h = 260, 44

        self.menu_buttons.append(MenuButton(
            center_x - btn_w // 2, start_y, btn_w, btn_h,
            "MODO CLÁSICO", (35, 45, 60), (50, 65, 90),
            text_color=(220, 220, 240), font_size=16,
            glow_color=(80, 120, 180), border_radius=10
        ))

        self.menu_buttons.append(MenuButton(
            center_x - btn_w // 2, start_y + 55, btn_w, btn_h,
            "MODO ADAPTATIVO (k-NN)", (35, 45, 60), (50, 65, 90),
            text_color=(220, 220, 240), font_size=16,
            glow_color=(80, 180, 120), border_radius=10
        ))

        self.menu_buttons.append(MenuButton(
            center_x - btn_w // 2, start_y + 130, btn_w, btn_h,
            "SALIR Y GENERAR REPORTES", (45, 30, 30), (70, 45, 45),
            text_color=(255, 150, 150), font_size=15,
            glow_color=(180, 80, 80), border_radius=10
        ))

    def _load_records(self):
        historial = load_web_data()
        for partida in historial:
            if partida.get("Rol_Humano") == "PREY":
                if partida.get("Tiempo_Partida", 0) > self.best_time:
                    self.best_time = partida["Tiempo_Partida"]
            elif partida.get("Rol_Humano") == "PREDATOR":
                if partida.get("Capturas_Humano", 0) > self.best_captures:
                    self.best_captures = partida["Capturas_Humano"]

            if partida.get("Puntuacion", 0) > self.best_score:
                self.best_score = partida["Puntuacion"]


    # NUEVO: Inicialización de música
    def _init_music(self):
        """Carga la música ambiental sin reinicializar el mixer (ya lo hace AudioManager)."""
        try:
            pygame.mixer.music.set_endevent(self.SONG_END)
            if os.path.exists(MUSIC_PATH):
                pygame.mixer.music.load(MUSIC_PATH)
                pygame.mixer.music.set_volume(0.6)
                print(f"[AUDIO] Música cargada: {MUSIC_PATH}")
            else:
                print(f"[ADVERTENCIA] No se encontró {MUSIC_PATH}")
        except Exception as e:
            print(f"[ERROR] No se pudo inicializar audio: {e}")

    # NUEVO: Reproducir música
    def _start_music(self):
        """Reproduce la música si está disponible."""
        if os.path.exists(MUSIC_PATH) and pygame.mixer.get_init():
            pygame.mixer.music.play(loops=0)
            print("[AUDIO] Reproduciendo música...")

    def reset_game(self):
        self.preys = []
        self.predators = []
        self.food_list = []
        self.food_spawn_timer = 0.0
        self.difficulty_level = 0
        self.difficulty_timer = 0.0
        self.difficulty_bonus = 0.0
        self.achievements_unlocked = set()
        self.achievement_queue = []
        self.proximity_alert_cooldown = 0.0
        self.music_victory = False

        for i in range(self.num_preys):
            is_human = (i == 0 and self.human_role == "PREY")
            self.preys.append(Prey(
                random.uniform(0, WORLD_W / 2),
                random.uniform(0, WORLD_H),
                is_human
            ))

        for i in range(self.num_preds):
            is_human = (i == 0 and self.human_role == "PREDATOR")
            self.predators.append(Predator(
                random.uniform(WORLD_W / 2, WORLD_W),
                random.uniform(0, WORLD_H),
                is_human
            ))

        self._spawn_food(5)
        self.time_elapsed = 0.0
        self.game_over = False
        self._start_music()

    def _spawn_food(self, count=1):
        for _ in range(count):
            if len(self.food_list) >= FOOD_MAX_COUNT:
                break
            x = random.uniform(FOOD_RADIUS * 2, WORLD_W - FOOD_RADIUS * 2)
            y = random.uniform(FOOD_RADIUS * 2, WORLD_H - FOOD_RADIUS * 2)
            self.food_list.append(Food(x, y))

    def get_human_entity(self):
        if self.human_role == "PREY":
            return self.preys[0] if self.preys and self.preys[0].alive else None
        return self.predators[0] if self.predators else None

    def _check_achievements(self):
        """Verifica y desbloquea logros durante la partida."""
        human = self.get_human_entity()
        if not human:
            return

        achievements = []

        if self.human_role == "PREDATOR":
            if human.captures >= 3 and "cazador_novato" not in self.achievements_unlocked:
                achievements.append(("cazador_novato", "¡Cazador Novato! 3 capturas", COLOR_ACHIEVEMENT))
            if human.captures >= 10 and "cazador_experto" not in self.achievements_unlocked:
                achievements.append(("cazador_experto", "¡Cazador Experto! 10 capturas", (255, 180, 50)))
            if human.best_combo >= 3 and "combo_master" not in self.achievements_unlocked:
                achievements.append(("combo_master", "¡Combo Master! x3 combo", COLOR_COMBO))
            if human.captures >= 20 and "depredador_legendario" not in self.achievements_unlocked:
                achievements.append(("depredador_legendario", "¡Depredador Legendario!", (255, 50, 50)))
        else:
            if self.time_elapsed >= 30 and "sobreviviente" not in self.achievements_unlocked:
                achievements.append(("sobreviviente", "¡Sobreviviente! 30s", COLOR_ACHIEVEMENT))
            if self.time_elapsed >= 60 and "resistente" not in self.achievements_unlocked:
                achievements.append(("resistente", "¡Resistente! 60s", (255, 180, 50)))
            if human.distance_traveled >= 5000 and "maratonista" not in self.achievements_unlocked:
                achievements.append(("maratonista", "¡Maratonista! 5000px", (100, 200, 255)))
            if self.time_elapsed >= 90 and "inmortal" not in self.achievements_unlocked:
                achievements.append(("inmortal", "¡Inmortal! 90s", (255, 50, 50)))

        for ach_id, text, color in achievements:
            self.achievements_unlocked.add(ach_id)
            self.visual_manager.spawn_achievement(text, color)

    def log_metrics(self):
        human = self.get_human_entity()
        if not human:
            return

        alive_preys = sum(1 for p in self.preys if p.alive)
        total_score = getattr(human, 'score', 0)
        if self.human_role == "PREDATOR":
            total_score += human.captures * 100

        row = {
            "Fecha": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "Modo": self.mode,
            "Rol_Humano": self.human_role,
            "Tiempo_Partida": round(self.time_elapsed, 2),
            "Presas_Sobrevivientes": alive_preys,
            "Distancia_Humano": round(human.distance_traveled, 2),
            "Capturas_Humano": getattr(human, 'captures', 0),
            "Puntuacion": total_score,
            "Dificultad": self.difficulty_level,
            "Logros": len(self.achievements_unlocked)
        }
        
        # Guardado web-safe (Compatible con Escritorio y Pygbag)
        historial = load_web_data()
        historial.append(row)
        save_web_data(historial)

        # Actualización de récords
        if self.human_role == "PREY" and self.time_elapsed > self.best_time:
            self.best_time = self.time_elapsed
        if self.human_role == "PREDATOR" and getattr(human, 'captures', 0) > self.best_captures:
            self.best_captures = getattr(human, 'captures', 0)
        if total_score > self.best_score:
            self.best_score = total_score

    # =================================================================
    # PANEL LATERAL (IN-GAME) MEJORADO
    # =================================================================
    def draw_panel(self):
        panel_x = WORLD_W

        panel_surface = pygame.Surface((PANEL_W, SCREEN_H), pygame.SRCALPHA)
        panel_surface.fill(COLOR_PANEL_BG)
        self.screen.blit(panel_surface, (panel_x, 0))
        pygame.draw.line(self.screen, COLOR_PANEL_BORDER, (panel_x, 0), (panel_x, SCREEN_H), 2)

        y = 15

        # Título
        title = self.font_title.render("PANEL DE CONTROL", True, COLOR_TEXT_ACCENT)
        self.screen.blit(title, (panel_x + (PANEL_W - title.get_width()) // 2, y))
        y += 30

        pygame.draw.line(self.screen, COLOR_PANEL_BORDER, (panel_x + 15, y), (panel_x + PANEL_W - 15, y), 1)
        y += 12

        # MODO
        mode_text = self.font_bold.render("MODO", True, COLOR_TEXT_SECONDARY)
        self.screen.blit(mode_text, (panel_x + 15, y))
        y += 18
        mode_val = self.font.render(self.mode, True, COLOR_TEXT_PRIMARY)
        self.screen.blit(mode_val, (panel_x + 15, y))
        y += 30

        # ROL
        role_text = self.font_bold.render("ROL HUMANO", True, COLOR_TEXT_SECONDARY)
        self.screen.blit(role_text, (panel_x + 15, y))
        y += 18
        role_color = COLOR_HUMAN_PREY if self.human_role == "PREY" else COLOR_HUMAN_PRED
        role_val = self.font.render(self.human_role, True, role_color)
        self.screen.blit(role_val, (panel_x + 15, y))
        y += 30

        pygame.draw.line(self.screen, COLOR_PANEL_BORDER, (panel_x + 15, y), (panel_x + PANEL_W - 15, y), 1)
        y += 12

        # TIEMPO
        time_text = self.font_bold.render("TIEMPO", True, COLOR_TEXT_SECONDARY)
        self.screen.blit(time_text, (panel_x + 15, y))
        y += 20
        time_val = self.font_number.render(f"{self.time_elapsed:.1f}s", True, COLOR_TEXT_PRIMARY)
        self.screen.blit(time_val, (panel_x + 15, y))
        y += 38

        progress = min(self.time_elapsed / EPISODE_TIME, 1.0)
        bar_w = PANEL_W - 30
        bar_h = 8
        pygame.draw.rect(self.screen, (40, 40, 40), (panel_x + 15, y, bar_w, bar_h), border_radius=4)
        prog_color = (50, 200, 50) if progress < 0.7 else (255, 200, 50) if progress < 0.9 else (255, 80, 80)
        pygame.draw.rect(self.screen, prog_color, (panel_x + 15, y, int(bar_w * progress), bar_h), border_radius=4)
        y += 26

        # NUEVO: Dificultad
        if DIFFICULTY_ENABLED and self.difficulty_level > 0:
            diff_text = self.font.render(f"Dif: Nivel {self.difficulty_level}", True, (255, 150, 100))
            self.screen.blit(diff_text, (panel_x + 15, y))
            y += 20

        pygame.draw.line(self.screen, COLOR_PANEL_BORDER, (panel_x + 15, y), (panel_x + PANEL_W - 15, y), 1)
        y += 12

        # POBLACIÓN
        pop_text = self.font_bold.render("POBLACIÓN", True, COLOR_TEXT_SECONDARY)
        self.screen.blit(pop_text, (panel_x + 15, y))
        y += 20

        alive_preys = sum(1 for p in self.preys if p.alive)
        babies = sum(1 for p in self.preys if p.alive and p.is_baby)

        prey_icon = pygame.Surface((12, 12), pygame.SRCALPHA)
        pygame.draw.circle(prey_icon, COLOR_AI_PREY, (6, 6), 5)
        self.screen.blit(prey_icon, (panel_x + 15, y + 2))
        prey_text = self.font.render(f"Presas: {alive_preys}/{self.num_preys}", True, COLOR_TEXT_PRIMARY)
        self.screen.blit(prey_text, (panel_x + 32, y))
        y += 18

        if babies > 0:
            baby_icon = pygame.Surface((10, 10), pygame.SRCALPHA)
            pygame.draw.circle(baby_icon, COLOR_BABY_PREY, (5, 5), 4)
            self.screen.blit(baby_icon, (panel_x + 32, y + 1))
            baby_text = self.font.render(f"Bebés: {babies}", True, COLOR_BABY_PREY)
            self.screen.blit(baby_text, (panel_x + 46, y))
            y += 18

        pred_icon = pygame.Surface((12, 12), pygame.SRCALPHA)
        pygame.draw.rect(pred_icon, COLOR_AI_PRED, (1, 1, 10, 10), border_radius=2)
        self.screen.blit(pred_icon, (panel_x + 15, y + 2))
        pred_text = self.font.render(f"Preds: {len(self.predators)}", True, COLOR_TEXT_PRIMARY)
        self.screen.blit(pred_text, (panel_x + 32, y))
        y += 18

        food_icon = pygame.Surface((10, 10), pygame.SRCALPHA)
        pygame.draw.circle(food_icon, FOOD_COLOR, (5, 5), 4)
        self.screen.blit(food_icon, (panel_x + 15, y + 1))
        food_count = sum(1 for f in self.food_list if f.alive)
        food_text = self.font.render(f"Alimento: {food_count}", True, FOOD_COLOR)
        self.screen.blit(food_text, (panel_x + 32, y))
        y += 30

        pygame.draw.line(self.screen, COLOR_PANEL_BORDER, (panel_x + 15, y), (panel_x + PANEL_W - 15, y), 1)
        y += 12

        # JUGADOR MEJORADO
        human = self.get_human_entity()
        if human:
            player_text = self.font_bold.render("JUGADOR", True, COLOR_TEXT_SECONDARY)
            self.screen.blit(player_text, (panel_x + 15, y))
            y += 20

            dist_text = self.font.render(f"Dist: {human.distance_traveled:.0f}px", True, COLOR_TEXT_PRIMARY)
            self.screen.blit(dist_text, (panel_x + 15, y))
            y += 18

            stam_text = self.font.render(f"Stamina: {human.stamina*100:.0f}%", True, 
                                        (255, 200, 50) if human.stamina < 0.3 else COLOR_TEXT_PRIMARY)
            self.screen.blit(stam_text, (panel_x + 15, y))
            y += 18

            # NUEVO: Score
            total_score = getattr(human, 'score', 0)
            if self.human_role == "PREDATOR":
                total_score += human.captures * 100
            score_text = self.font.render(f"Score: {total_score}", True, COLOR_TEXT_ACCENT)
            self.screen.blit(score_text, (panel_x + 15, y))
            y += 20

            if hasattr(human, 'captures') and human.captures > 0:
                cap_text = self.font.render(f"Capturas: {human.captures}", True, COLOR_TEXT_PRIMARY)
                self.screen.blit(cap_text, (panel_x + 15, y))
                y += 18
                # NUEVO: Combo
                if hasattr(human, 'combo_count') and human.combo_count >= 2:
                    combo_text = self.font.render(f"Combo: x{human.combo_multiplier:.1f}", True, COLOR_COMBO)
                    self.screen.blit(combo_text, (panel_x + 15, y))
                    y += 18

            # NUEVO: Estados especiales
            if hasattr(human, 'has_boost') and human.has_boost:
                boost_text = self.font.render(f"BOOST: {human.boost_timer:.1f}s", True, COLOR_BOOST_ACTIVE)
                self.screen.blit(boost_text, (panel_x + 15, y))
                y += 18
            if hasattr(human, 'is_invincible') and human.is_invincible:
                inv_text = self.font.render(f"INVENCIBLE: {human.invincible_timer:.1f}s", True, COLOR_INVINCIBLE)
                self.screen.blit(inv_text, (panel_x + 15, y))
                y += 18
            if hasattr(human, 'has_magnet') and human.has_magnet:
                mag_text = self.font.render(f"IMÁN: {human.magnet_timer:.1f}s", True, COLOR_MAGNET)
                self.screen.blit(mag_text, (panel_x + 15, y))
                y += 18

        y += 8
        pygame.draw.line(self.screen, COLOR_PANEL_BORDER, (panel_x + 15, y), (panel_x + PANEL_W - 15, y), 1)
        y += 12

        # NUEVO: LOGROS
        if self.achievements_unlocked:
            ach_text = self.font_bold.render(f"LOGROS ({len(self.achievements_unlocked)})", True, COLOR_ACHIEVEMENT)
            self.screen.blit(ach_text, (panel_x + 15, y))
            y += 20
            for ach_id in list(self.achievements_unlocked)[:3]:
                ach_label = self.font_small.render(f"• {ach_id.replace('_', ' ').title()}", True, (180, 170, 140))
                self.screen.blit(ach_label, (panel_x + 20, y))
                y += 14
            if len(self.achievements_unlocked) > 3:
                more = self.font_small.render(f"+{len(self.achievements_unlocked) - 3} más...", True, (120, 120, 120))
                self.screen.blit(more, (panel_x + 20, y))
                y += 14
            y += 8
            pygame.draw.line(self.screen, COLOR_PANEL_BORDER, (panel_x + 15, y), (panel_x + PANEL_W - 15, y), 1)
            y += 12

        # RÉCORDS
        record_text = self.font_bold.render("RÉCORDS", True, COLOR_TEXT_SECONDARY)
        self.screen.blit(record_text, (panel_x + 15, y))
        y += 20

        if self.human_role == "PREY":
            rec_label = self.font.render("Mejor Tiempo:", True, COLOR_TEXT_PRIMARY)
            self.screen.blit(rec_label, (panel_x + 15, y))
            y += 16
            rec_val = self.font_record.render(f"{self.best_time:.1f}s", True, COLOR_TEXT_RECORD)
            self.screen.blit(rec_val, (panel_x + 15, y))
        else:
            rec_label = self.font.render("Mejor Capturas:", True, COLOR_TEXT_PRIMARY)
            self.screen.blit(rec_label, (panel_x + 15, y))
            y += 16
            rec_val = self.font_record.render(f"{self.best_captures}", True, COLOR_TEXT_RECORD)
            self.screen.blit(rec_val, (panel_x + 15, y))
        y += 28

        # NUEVO: Best Score
        score_label = self.font.render("Mejor Score:", True, COLOR_TEXT_PRIMARY)
        self.screen.blit(score_label, (panel_x + 15, y))
        y += 16
        score_val = self.font_record.render(f"{self.best_score}", True, COLOR_TEXT_ACCENT)
        self.screen.blit(score_val, (panel_x + 15, y))
        y += 30

        pygame.draw.line(self.screen, COLOR_PANEL_BORDER, (panel_x + 15, y), (panel_x + PANEL_W - 15, y), 1)
        y += 12

        # CONTROLES
        controls_text = self.font_bold.render("CONTROLES", True, COLOR_TEXT_SECONDARY)
        self.screen.blit(controls_text, (panel_x + 15, y))
        y += 20

        controls = [
            "WASD / Flechas",
            "ESPACIO: Sprint",
            "ESC: Menú",
            "R: Reiniciar",
            "+/-: Presas",
            "./,: Preds"
        ]
        for ctrl in controls:
            ctrl_text = self.font.render(ctrl, True, COLOR_TEXT_SECONDARY)
            self.screen.blit(ctrl_text, (panel_x + 15, y))
            y += 16

        # Logo
        logo_y = SCREEN_H - 55
        logo = self.font.render("ÁPEX: Instinto Artificial v3.0", True, (80, 90, 110))
        self.screen.blit(logo, (panel_x + (PANEL_W - logo.get_width()) // 2, logo_y))

    # =================================================================
    # MENÚ PRINCIPAL MEJORADO
    # =================================================================
    def _spawn_menu_particles(self, dt):
        if random.random() < 0.3:
            colors = [COLOR_PARTICLE_PREY, COLOR_PARTICLE_PRED, FOOD_COLOR, COLOR_HUMAN_GLOW, (100, 150, 255)]
            x = random.uniform(0, WORLD_W)
            y = random.uniform(0, WORLD_H)
            color = random.choice(colors)
            self.menu_particles.append(MenuParticle(
                x, y, color, 
                speed=random.uniform(10, 40),
                size=random.uniform(1, 3),
                lifetime=random.uniform(2.0, 5.0)
            ))

    def _update_menu_particles(self, dt):
        for p in self.menu_particles:
            p.update(dt)
        self.menu_particles = [p for p in self.menu_particles if p.alive]

    def _draw_menu_particles(self):
        for p in self.menu_particles:
            p.draw(self.screen, self.menu_time)


    def _draw_menu_config_panel(self, center_x, y_base):
        panel_w = 280
        panel_h = 90
        panel_x = center_x - panel_w // 2
        panel_y = y_base

        config_surface = pygame.Surface((panel_w, panel_h), pygame.SRCALPHA)
        config_surface.fill((20, 25, 35, 200))
        self.screen.blit(config_surface, (panel_x, panel_y))
        pygame.draw.rect(self.screen, (50, 60, 80), (panel_x, panel_y, panel_w, panel_h), 1, border_radius=6)

        title = self.font_bold.render("CONFIGURACIÓN", True, (150, 160, 180))
        self.screen.blit(title, (panel_x + 15, panel_y + 8))

        y1 = panel_y + 32
        prey_label = self.font.render("Presas:", True, COLOR_AI_PREY)
        self.screen.blit(prey_label, (panel_x + 15, y1))

        bar_x = panel_x + 80
        bar_w = 120
        bar_h = 10
        pygame.draw.rect(self.screen, (30, 35, 45), (bar_x, y1 + 2, bar_w, bar_h), border_radius=5)
        prey_progress = min(self.num_preys / 100, 1.0)
        prey_bar_color = tuple(int(c * 0.7) for c in COLOR_AI_PREY)
        pygame.draw.rect(self.screen, prey_bar_color, (bar_x, y1 + 2, int(bar_w * prey_progress), bar_h), border_radius=5)

        prey_val = self.font_bold.render(str(self.num_preys), True, COLOR_AI_PREY)
        self.screen.blit(prey_val, (bar_x + bar_w + 8, y1))

        y2 = panel_y + 58
        pred_label = self.font.render("Preds:", True, COLOR_AI_PRED)
        self.screen.blit(pred_label, (panel_x + 15, y2))

        bar_x2 = panel_x + 80
        pygame.draw.rect(self.screen, (30, 35, 45), (bar_x2, y2 + 2, bar_w, bar_h), border_radius=5)
        pred_progress = min(self.num_preds / 10, 1.0)
        pred_bar_color = tuple(int(c * 0.7) for c in COLOR_AI_PRED)
        pygame.draw.rect(self.screen, pred_bar_color, (bar_x2, y2 + 2, int(bar_w * pred_progress), bar_h), border_radius=5)

        pred_val = self.font_bold.render(str(self.num_preds), True, COLOR_AI_PRED)
        self.screen.blit(pred_val, (bar_x2 + bar_w + 8, y2))

        hint = self.font_small.render("+/-  Presas  |  ./,  Preds", True, (80, 90, 110))
        self.screen.blit(hint, (panel_x + panel_w - hint.get_width() - 10, panel_y + panel_h - 16))


    def _draw_menu_role_preview_v2(self, center_x, y_base):
        """Preview minimalista del rol seleccionado."""
        self.menu_role_anim += 0.015

        pulse = 1.0 + 0.08 * math.sin(self.menu_role_anim * 2)
        glow_r = int(35 * pulse)

        glow_surface = pygame.Surface((glow_r * 2, glow_r * 2), pygame.SRCALPHA)

        if self.human_role == "PREY":
            glow_color = (*COLOR_HUMAN_PREY, 20)
            entity_color = COLOR_HUMAN_PREY
            pygame.draw.circle(glow_surface, glow_color, (glow_r, glow_r), glow_r)
            self.screen.blit(glow_surface, (center_x - glow_r, y_base - glow_r))
            pygame.draw.circle(self.screen, entity_color, (center_x, y_base), PREY_RADIUS + 2)
            pygame.draw.circle(self.screen, COLOR_HUMAN_GLOW, (center_x, y_base), PREY_RADIUS + 5, 1)
        else:
            glow_color = (*COLOR_HUMAN_PRED, 20)
            entity_color = COLOR_HUMAN_PRED
            half = PRED_SIZE // 2 + 1
            pygame.draw.circle(glow_surface, glow_color, (glow_r, glow_r), glow_r)
            self.screen.blit(glow_surface, (center_x - glow_r, y_base - glow_r))
            rect = pygame.Rect(center_x - half, y_base - half, PRED_SIZE + 2, PRED_SIZE + 2)
            pygame.draw.rect(self.screen, entity_color, rect, border_radius=3)
            pygame.draw.circle(self.screen, COLOR_HUMAN_GLOW, (center_x, y_base), half + 4, 1)
            # Triángulo indicador
            pygame.draw.polygon(self.screen, COLOR_HUMAN_GLOW, [
                (center_x, y_base - half - 6),
                (center_x - 3, y_base - half - 2),
                (center_x + 3, y_base - half - 2)
            ])

    def draw_menu(self):
        """Menú principal con distribución limpia y profesional."""
        self.visual_manager.draw_background(self.screen)
        self._draw_menu_particles()

        center_x = WORLD_W // 2

        # ZONA 1: TÍTULO (arriba)
        self._draw_menu_title_zone(center_x, 30)

        # ZONA 2: PREVIEW + CONFIG (centro-arriba)
        self._draw_menu_content_zone(center_x, 155)

        # ZONA 3: BOTONES (centro)
        self._draw_menu_buttons_zone(center_x, 360)

        # ZONA 4: CRÉDITOS (abajo)
        self._draw_menu_credits_zone(center_x, 690)

        # Panel lateral
        self.draw_menu_panel()

    def _draw_menu_title_zone(self, center_x, y_base):
        """Zona del título - limpia y centrada."""

        pulse = 1.0 + 0.08 * math.sin(self.menu_time * 2)
        glow_w = int(350 * pulse)
        glow_h = int(70 * pulse)
        glow_surface = pygame.Surface((glow_w, glow_h), pygame.SRCALPHA)
        for i in range(4, 0, -1):
            alpha = int(5 * i)
            w = glow_w * i // 4
            h = glow_h * i // 4
            pygame.draw.ellipse(glow_surface, (255, 140, 30, alpha),
                              (glow_w//2 - w//2, glow_h//2 - h//2, w, h))
        self.screen.blit(glow_surface, (center_x - glow_w//2, y_base + 10))

        title_font = pygame.font.SysFont("Impact", 56, bold=True)
        title_main = "ÁPEX"
        title_color = (255, 200, 80)
        title_accent = (255, 140, 40)

        for dx, dy in [(-2,-2), (2,-2), (-2,2), (2,2), (0,-2), (0,2), (-2,0), (2,0)]:
            outline = title_font.render(title_main, True, title_accent)
            self.screen.blit(outline, (center_x - outline.get_width()//2 + dx, y_base + 5 + dy))

        title_surf = title_font.render(title_main, True, title_color)
        self.screen.blit(title_surf, (center_x - title_surf.get_width()//2, y_base + 5))

        shine_alpha = int(40 + 30 * math.sin(self.menu_time * 3))
        shine_surf = pygame.Surface((title_surf.get_width(), 2), pygame.SRCALPHA)
        shine_surf.fill((255, 255, 220, shine_alpha))
        self.screen.blit(shine_surf, (center_x - title_surf.get_width()//2, y_base + 28))

        sub_font = pygame.font.SysFont("Arial", 20, bold=True)
        sub_text = "Instinto Artificial"
        sub_color = (140, 200, 255)

        for dx, dy in [(-1,-1), (1,-1), (-1,1), (1,1)]:
            sub_out = sub_font.render(sub_text, True, (30, 60, 90))
            self.screen.blit(sub_out, (center_x - sub_out.get_width()//2 + dx, y_base + 62 + dy))

        sub_surf = sub_font.render(sub_text, True, sub_color)
        self.screen.blit(sub_surf, (center_x - sub_surf.get_width()//2, y_base + 62))

        tag_font = pygame.font.SysFont("Arial", 12, italic=True)
        tag_surf = tag_font.render("Tu mente es su arma", True, (110, 120, 140))
        self.screen.blit(tag_surf, (center_x - tag_surf.get_width()//2, y_base + 88))

        line_y = y_base + 108
        line_w = 200
        pygame.draw.line(self.screen, (50, 60, 75),
                        (center_x - line_w//2, line_y),
                        (center_x + line_w//2, line_y), 1)

    def _draw_menu_content_zone(self, center_x, y_base):
        """Zona de contenido: Preview IZQUIERDA, Configuración DERECHA."""

        zone_w = 480
        zone_h = 170
        zone_x = center_x - zone_w // 2
        zone_y = y_base

        bg_surface = pygame.Surface((zone_w, zone_h), pygame.SRCALPHA)
        bg_surface.fill((18, 22, 32, 180))
        self.screen.blit(bg_surface, (zone_x, zone_y))
        pygame.draw.rect(self.screen, (35, 42, 55), (zone_x, zone_y, zone_w, zone_h), 1, border_radius=8)

        # COLUMNA IZQUIERDA: Preview del Rol
        col1_x = zone_x + 30
        col1_center = col1_x + 80

        role_label_font = pygame.font.SysFont("Arial", 13, bold=True)
        role_label = role_label_font.render("ROL DEL JUGADOR", True, (130, 140, 160))
        self.screen.blit(role_label, (col1_center - role_label.get_width()//2, zone_y + 12))

        preview_y = zone_y + 45
        self._draw_menu_role_preview_v2(col1_center, preview_y)

        role_name_font = pygame.font.SysFont("Arial", 14, bold=True)
        if self.human_role == "PREY":
            role_name = "PRESA"
            role_color = COLOR_HUMAN_PREY
        else:
            role_name = "DEPREDADOR"
            role_color = COLOR_HUMAN_PRED
        role_name_surf = role_name_font.render(role_name, True, role_color)
        self.screen.blit(role_name_surf, (col1_center - role_name_surf.get_width()//2, preview_y + 38))

        hint_font = pygame.font.SysFont("Arial", 11)
        hint_surf = hint_font.render("[P] Presa  |  [D] Depredador", True, (100, 110, 130))
        self.screen.blit(hint_surf, (col1_center - hint_surf.get_width()//2, preview_y + 56))

        # LÍNEA DIVISORIA VERTICAL
        div_x = zone_x + 195
        pygame.draw.line(self.screen, (40, 48, 60),
                        (div_x, zone_y + 15),
                        (div_x, zone_y + zone_h - 15), 1)

        # COLUMNA DERECHA: Configuración
        col2_x = div_x + 25

        config_label = role_label_font.render("CONFIGURACIÓN", True, (130, 140, 160))
        self.screen.blit(config_label, (col2_x, zone_y + 12))

        y1 = zone_y + 42
        prey_label = self.font.render("Presas:", True, COLOR_AI_PREY)
        self.screen.blit(prey_label, (col2_x, y1))

        bar_x = col2_x + 65
        bar_w = 140
        bar_h = 10
        pygame.draw.rect(self.screen, (25, 30, 38), (bar_x, y1 + 2, bar_w, bar_h), border_radius=5)
        prey_progress = min(self.num_preys / 100, 1.0)
        prey_bar = tuple(int(c * 0.6) for c in COLOR_AI_PREY)
        pygame.draw.rect(self.screen, prey_bar, (bar_x, y1 + 2, int(bar_w * prey_progress), bar_h), border_radius=5)
        prey_val = self.font_bold.render(str(self.num_preys), True, COLOR_AI_PREY)
        self.screen.blit(prey_val, (bar_x + bar_w + 10, y1))

        y2 = zone_y + 72
        pred_label = self.font.render("Preds:", True, COLOR_AI_PRED)
        self.screen.blit(pred_label, (col2_x, y2))

        pygame.draw.rect(self.screen, (25, 30, 38), (bar_x, y2 + 2, bar_w, bar_h), border_radius=5)
        pred_progress = min(self.num_preds / 10, 1.0)
        pred_bar = tuple(int(c * 0.6) for c in COLOR_AI_PRED)
        pygame.draw.rect(self.screen, pred_bar, (bar_x, y2 + 2, int(bar_w * pred_progress), bar_h), border_radius=5)
        pred_val = self.font_bold.render(str(self.num_preds), True, COLOR_AI_PRED)
        self.screen.blit(pred_val, (bar_x + bar_w + 10, y2))

        sep_y = zone_y + 105
        pygame.draw.line(self.screen, (35, 42, 55), (col2_x, sep_y), (col2_x + 210, sep_y), 1)

        features = [
            ("⚡", "Instinto de Supervivencia", FOOD_COLOR),
            ("🧬", "Evolución Artificial", COLOR_BABY_PREY),
            ("🧠", "IA que aprende de TI", (100, 180, 255)),
        ]

        feat_y = zone_y + 115
        badge_w = 200
        badge_h = 22
        for i, (icon, text, color) in enumerate(features):
            by = feat_y + i * 26
            badge_surface = pygame.Surface((badge_w, badge_h), pygame.SRCALPHA)
            badge_surface.fill((*color, 18))
            self.screen.blit(badge_surface, (col2_x, by))
            pygame.draw.rect(self.screen, (*color, 60), (col2_x, by, badge_w, badge_h), 1, border_radius=3)

            feat_font = pygame.font.SysFont("Arial", 10, bold=True)
            feat_text = feat_font.render(text, True, color)
            self.screen.blit(feat_text, (col2_x + 8, by + badge_h//2 - feat_text.get_height()//2))


    def _draw_menu_buttons_zone(self, center_x, y_base):
        """Zona de botones - centrados y espaciados."""

        # Label
        btn_label_font = pygame.font.SysFont("Arial", 12, bold=True)
        btn_label = btn_label_font.render("MODO DE JUEGO", True, (120, 130, 150))
        self.screen.blit(btn_label, (center_x - btn_label.get_width()//2, y_base - 5))

        # Actualizar y dibujar botones
        for i, btn in enumerate(self.menu_buttons):
            btn.rect.centerx = center_x
            btn.rect.y = y_base + 18 + i * 52
            btn.draw(self.screen)

        # Hint de controles debajo de los botones
        hint_y = y_base + 18 + len(self.menu_buttons) * 52 + 8
        hint = self.font_small.render("[1] Clásico    [2] Adaptativo    [Q] Salir", True, (90, 100, 120))
        self.screen.blit(hint, (center_x - hint.get_width()//2, hint_y))

    def _draw_menu_credits_zone(self, center_x, y_base):
        """Zona de créditos - elegante y discreta en la parte inferior."""

        # Línea separadora superior
        sep_w = 300
        pygame.draw.line(self.screen, (35, 42, 55),
                        (center_x - sep_w//2, y_base),
                        (center_x + sep_w//2, y_base), 1)

        # Label "DESARROLLADO POR"
        dev_label_font = pygame.font.SysFont("Arial", 10, bold=True)
        dev_label = dev_label_font.render("DESARROLLADO POR", True, (80, 90, 110))
        self.screen.blit(dev_label, (center_x - dev_label.get_width()//2, y_base + 10))

        # Nombres de desarrolladores
        devs = ["Iron_Axl", "BiosCandJhade", "luciatelloleon-max"]
        dev_font = pygame.font.SysFont("Arial", 12, bold=True)

        # Calcular posiciones para centrar los 3 nombres
        total_width = 0
        dev_surfs = []
        for dev in devs:
            surf = dev_font.render(dev, True, (160, 170, 190))
            dev_surfs.append(surf)
            total_width += surf.get_width()

        # Espaciado entre nombres
        spacing = 40
        total_width += spacing * (len(devs) - 1)
        start_x = center_x - total_width // 2

        current_x = start_x
        for i, surf in enumerate(dev_surfs):
            # Hover effect sutil
            mouse_x, mouse_y = pygame.mouse.get_pos()
            dev_rect = pygame.Rect(current_x - 5, y_base + 28, surf.get_width() + 10, 20)

            if dev_rect.collidepoint(mouse_x, mouse_y):
                # Glow al pasar el mouse
                glow_surf = pygame.Surface((surf.get_width() + 12, 22), pygame.SRCALPHA)
                glow_surf.fill((255, 200, 80, 15))
                self.screen.blit(glow_surf, (current_x - 6, y_base + 27))
                color = (255, 200, 100)
            else:
                color = (160, 170, 190)

            # Re-render con color correcto
            surf = dev_font.render(devs[i], True, color)
            self.screen.blit(surf, (current_x, y_base + 28))

            # Separador entre nombres (excepto el último)
            if i < len(devs) - 1:
                sep_x = current_x + surf.get_width() + spacing // 2
                pygame.draw.circle(self.screen, (60, 70, 85), (int(sep_x), int(y_base + 36)), 2)

            current_x += surf.get_width() + spacing

        # Versión pequeña
        version_font = pygame.font.SysFont("Arial", 10)
        version_surf = version_font.render("v3.0 · Multi-Agente & Machine Learning", True, (60, 70, 85))
        self.screen.blit(version_surf, (center_x - version_surf.get_width()//2, y_base + 52))


    def draw_menu_panel(self):
        panel_x = WORLD_W

        panel_surface = pygame.Surface((PANEL_W, SCREEN_H), pygame.SRCALPHA)
        panel_surface.fill(COLOR_PANEL_BG)
        self.screen.blit(panel_surface, (panel_x, 0))
        pygame.draw.line(self.screen, COLOR_PANEL_BORDER, (panel_x, 0), (panel_x, SCREEN_H), 2)

        y = 30

        title = self.font_title.render("ESTADÍSTICAS", True, COLOR_TEXT_ACCENT)
        self.screen.blit(title, (panel_x + (PANEL_W - title.get_width()) // 2, y))
        y += 50

        # --- NUEVO SISTEMA DE LECTURA JSON ---
        historial = load_web_data()
        
        if historial:
            total_games = len(historial)
            games_text = self.font.render(f"Partidas: {total_games}", True, COLOR_TEXT_PRIMARY)
            self.screen.blit(games_text, (panel_x + 15, y))
            y += 25

            if self.best_time > 0:
                best_text = self.font.render(f"Mejor Tiempo: {self.best_time:.1f}s", True, COLOR_TEXT_RECORD)
                self.screen.blit(best_text, (panel_x + 15, y))
                y += 25

            if self.best_captures > 0:
                best_cap_text = self.font.render(f"Mejor Capturas: {int(self.best_captures)}", True, COLOR_TEXT_RECORD)
                self.screen.blit(best_cap_text, (panel_x + 15, y))
                y += 25

            if self.best_score > 0:
                score_text = self.font.render(f"Mejor Score: {int(self.best_score)}", True, COLOR_TEXT_ACCENT)
                self.screen.blit(score_text, (panel_x + 15, y))
                y += 25
        else:
            no_data = self.font.render("Sin datos aún", True, COLOR_TEXT_SECONDARY)
            self.screen.blit(no_data, (panel_x + 15, y))
            y += 25

        y += 30
        pygame.draw.line(self.screen, COLOR_PANEL_BORDER, (panel_x + 15, y), (panel_x + PANEL_W - 15, y), 1)
        y += 20

        controls_text = self.font_bold.render("CONTROLES", True, COLOR_TEXT_SECONDARY)
        self.screen.blit(controls_text, (panel_x + 15, y))
        y += 25

        controls = [
            "P: Elegir Presa",
            "D: Elegir Depredador",
            "+/-: Ajustar Presas",
            "./,: Ajustar Preds",
            "1: Modo Clásico",
            "2: Modo Adaptativo",
            "Q: Salir"
        ]
        for ctrl in controls:
            ctrl_text = self.font.render(ctrl, True, COLOR_TEXT_SECONDARY)
            self.screen.blit(ctrl_text, (panel_x + 15, y))
            y += 20

    def _handle_menu_input(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for i, btn in enumerate(self.menu_buttons):
                if btn.is_clicked(event):
                    if i == 0:
                        self.mode = "CLASSIC"
                        self.reset_game()
                        return True
                    elif i == 1:
                        self.mode = "ADAPTIVE"
                        self.reset_game()
                        return True
                    elif i == 2:
                        return False
                    elif event.key == pygame.K_g:
                        self.dashboard.toggle() 

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_1:
                self.mode = "CLASSIC"
                self.reset_game()
            elif event.key == pygame.K_2:
                self.mode = "ADAPTIVE"
                self.reset_game()
            elif event.key == pygame.K_p:
                self.human_role = "PREY"
            elif event.key == pygame.K_d:
                self.human_role = "PREDATOR"
            elif event.key in (pygame.K_PLUS, pygame.K_KP_PLUS):
                self.num_preys += 5
            elif event.key in (pygame.K_MINUS, pygame.K_KP_MINUS):
                self.num_preys = max(1, self.num_preys - 5)
            elif event.key == pygame.K_PERIOD:
                self.num_preds += 1
            elif event.key == pygame.K_COMMA:
                self.num_preds = max(1, self.num_preds - 1)
            elif event.key == pygame.K_q:
                return False
        return True

    def _handle_game_input(self, event):
        if event.key == pygame.K_ESCAPE:
            self.mode = "MENU"
        elif event.key == pygame.K_r:
            if not self.game_over:
                self.log_metrics()
                self.ai_controller.save_and_train(self.human_role)
            self.reset_game()
        elif event.key in (pygame.K_PLUS, pygame.K_KP_PLUS):
            self.num_preys += 5
            self.reset_game()
        elif event.key in (pygame.K_MINUS, pygame.K_KP_MINUS):
            self.num_preys = max(1, self.num_preys - 5)
            self.reset_game()
        elif event.key == pygame.K_PERIOD:
            self.num_preds += 1
            self.reset_game()
        elif event.key == pygame.K_COMMA:
            self.num_preds = max(1, self.num_preds - 1)
            self.reset_game()
        return True

    def _update_entities(self, dt, keys):
        for p in self.preys:
            if not p.alive:
                continue
            if p.is_human:
                p.move_human(keys, dt)
            else:
                p.move_ai(self.predators, dt, self.mode, self.food_list, self.difficulty_bonus)

        for d in self.predators:
            if d.is_human:
                d.move_human(keys, dt)
            else:
                d.move_ai(self.preys, dt, self.mode, self.difficulty_bonus)

    def _check_food_collision(self):
        for prey in self.preys:
            if not prey.alive:
                continue

            for food in self.food_list:
                if not food.alive:
                    continue

                dist = distancia_toroidal(prey.pos[0], prey.pos[1], food.pos[0], food.pos[1])
                if dist < (PREY_RADIUS + FOOD_RADIUS + 3):
                    food.alive = False
                    prey.apply_food_boost(food.food_type)
                    self.visual_manager.spawn_food_collect(food.pos[0], food.pos[1], food.food_type)

    def _check_breeding(self):
        if not BREEDING_ENABLED:
            return

        alive_preys = [p for p in self.preys if p.alive and not p.is_baby]

        for i, prey1 in enumerate(alive_preys):
            if not prey1.can_breed or prey1.stamina < BREEDING_MIN_STAMINA:
                continue

            for prey2 in alive_preys[i+1:]:
                if not prey2.can_breed or prey2.stamina < BREEDING_MIN_STAMINA:
                    continue

                dist = distancia_toroidal(prey1.pos[0], prey1.pos[1], prey2.pos[0], prey2.pos[1])

                if dist < BREEDING_PROXIMITY:
                    if random.random() < BREEDING_CHANCE:
                        baby_x = (prey1.pos[0] + prey2.pos[0]) / 2
                        baby_y = (prey1.pos[1] + prey2.pos[1]) / 2

                        baby = Prey(baby_x, baby_y, is_human=False, is_baby=True)
                        self.preys.append(baby)

                        prey1.stamina -= BABY_STAMINA_PENALTY
                        prey2.stamina -= BABY_STAMINA_PENALTY
                        prey1.breeding_timer = 0.0
                        prey2.breeding_timer = 0.0
                        prey1.can_breed = False
                        prey2.can_breed = False

                        self.visual_manager.spawn_breeding(baby_x, baby_y)
                        return

    def _check_collisions(self):
        for d in self.predators:
            for p in self.preys:
                if p.alive and distancia_toroidal(
                    p.pos[0], p.pos[1], d.pos[0], d.pos[1]
                ) < CAPTURE_RADIUS:
                    # NUEVO: Si la presa es invencible, no muere
                    if p.is_invincible:
                        continue
                    p.alive = False
                    combo_count, combo_mult = d.add_capture(p.pos)
                    d.score += int(100 * combo_mult)
                    self.visual_manager.spawn_death(p.pos[0], p.pos[1])
                    if d.is_human:
                        self.visual_manager.spawn_capture(d.pos[0], d.pos[1], combo_mult)
                        if combo_count >= 2:
                            self.visual_manager.spawn_combo(d.pos[0], d.pos[1], combo_count, combo_mult)

    def _check_proximity_alerts(self, dt):
        """Alertas visuales MUY SUTILES solo cuando el peligro es inminente."""
        self.proximity_alert_cooldown -= dt
        if self.proximity_alert_cooldown > 0:
            return

        human = self.get_human_entity()
        if not human or not human.alive:
            return

        # Solo mostrar alerta cuando el enemigo está MUY cerca (distancia crítica)
        CRITICAL_DIST_PREY = 50   # Solo cuando depredador está a 50px o menos
        CRITICAL_DIST_PRED = 40   # Solo cuando presa está a 40px o menos

        if self.human_role == "PREY":
            for pred in self.predators:
                dist = distancia_toroidal(human.pos[0], human.pos[1], pred.pos[0], pred.pos[1])
                if dist < CRITICAL_DIST_PREY:
                    self.visual_manager.spawn_proximity_alert(human.pos[0], human.pos[1], 
                                                             int(dist), is_danger=True)
                    self.proximity_alert_cooldown = 1.0  # Más espaciado
                    return
        else:
            for prey in self.preys:
                if prey.alive:
                    dist = distancia_toroidal(human.pos[0], human.pos[1], prey.pos[0], prey.pos[1])
                    if dist < CRITICAL_DIST_PRED:
                        self.visual_manager.spawn_proximity_alert(human.pos[0], human.pos[1], 
                                                                 int(dist), is_danger=False)
                        self.proximity_alert_cooldown = 1.0
                        return

    def _update_difficulty(self, dt):
        """Aumenta la dificultad progresivamente."""
        if not DIFFICULTY_ENABLED:
            return
        self.difficulty_timer += dt
        if self.difficulty_timer >= DIFFICULTY_SCALE_EVERY:
            self.difficulty_timer = 0.0
            if self.difficulty_bonus < DIFFICULTY_MAX_BONUS:
                self.difficulty_level += 1
                self.difficulty_bonus = min(DIFFICULTY_MAX_BONUS, self.difficulty_level * DIFFICULTY_SPEED_BONUS)
                # Notificar
                if self.difficulty_level > 0:
                    self.visual_manager.spawn_achievement(
                        f"¡Dificultad Nivel {self.difficulty_level}!", (255, 100, 100)
                    )

    def _check_game_over(self):
        human = self.get_human_entity()
        alive_count = sum(1 for p in self.preys if p.alive)

        if not human or self.time_elapsed >= EPISODE_TIME or alive_count == 0 or self.music_victory:
            self.game_over = True
            self.log_metrics()
            self.ai_controller.save_and_train(self.human_role)

    def _draw_game(self):
        # NUEVO: Aplicar screen shake offset
        shake = self.visual_manager.get_shake_offset()

        # Fondo del área de juego (sin shake para el fondo)
        self.visual_manager.draw_background(self.screen)

        # Crear surface temporal para todo el juego con shake
        game_surface = pygame.Surface((WORLD_W, WORLD_H), pygame.SRCALPHA)

        # Alimento
        for food in self.food_list:
            if food.alive:
                food.draw(game_surface, self.time_elapsed)

        # Trails
        all_entities = self.preys + self.predators
        self.visual_manager.draw_trails(game_surface, all_entities)

        # NUEVO: Alertas de proximidad DETRÁS de las entidades (para no obstruir)
        # Solo dibujar los alerts de proximidad, no otros efectos
        for alert in self.visual_manager.proximity_alerts:
            alert.draw(game_surface)

        # Entidades (dibujadas ENCIMA de las alertas)
        for p in self.preys:
            p.draw(game_surface, self.time_elapsed)
        for d in self.predators:
            d.draw(game_surface, self.time_elapsed)

        # Efectos visuales (partículas, textos, etc.) - ENCIMA de todo
        # PERO excluir los proximity alerts que ya dibujamos
        self._draw_effects_without_alerts(game_surface)

        # Blit con shake
        self.screen.blit(game_surface, (shake[0], shake[1]))

        # Panel lateral (sin shake)
        self.draw_panel()

        # Pantalla de fin de juego MEJORADA
        if self.game_over:
            self._draw_game_over_screen()

    def _draw_effects_without_alerts(self, screen):
        """Dibuja todos los efectos EXCEPTO los proximity alerts."""
        vm = self.visual_manager
        for p in vm.particles:
            p.draw(screen)
        for e in vm.capture_effects:
            e.draw(screen)
        for w in vm.impact_waves:
            w.draw(screen)
        for t in vm.floating_texts:
            t.draw(screen)
        for c in vm.combo_texts:
            c.draw(screen)
        for a in vm.achievement_popups:
            a.draw(screen)
        # Flash de slow motion
        flash_alpha = vm.get_slowmo_flash()
        if flash_alpha > 0:
            flash_surface = pygame.Surface((WORLD_W, WORLD_H), pygame.SRCALPHA)
            flash_surface.fill((255, 255, 255, flash_alpha))
            screen.blit(flash_surface, (0, 0))

    def _draw_game_over_screen(self):
        """Pantalla de fin de partida mejorada con estadísticas completas."""
        overlay = pygame.Surface((WORLD_W, WORLD_H), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 140))
        self.screen.blit(overlay, (0, 0))

        center_x = WORLD_W // 2
        y = WORLD_H // 2 - 120

        # NUEVO: Título diferente si es victoria por música
        if self.music_victory:
            title_text = "¡VICTORIA!"
            title_color = (255, 215, 0)  # Dorado
            shadow_color = (120, 90, 0)
        else:
            title_text = "FIN DE PARTIDA"
            title_color = (255, 80, 80)
            shadow_color = (80, 20, 20)

        title = self.font_huge.render(title_text, True, title_color)
        title_shadow = self.font_huge.render(title_text, True, shadow_color)
        self.screen.blit(title_shadow, (center_x - title.get_width()//2 + 4, y + 4))
        self.screen.blit(title, (center_x - title.get_width()//2, y))
        y += 60

        human = self.get_human_entity()
        if human:
            # Estadísticas principales
            stats = []
            if self.human_role == "PREY":
                stats.append(("ROL", "PRESA", COLOR_HUMAN_PREY))
                stats.append(("TIEMPO", f"{self.time_elapsed:.1f}s", COLOR_TEXT_PRIMARY))
                stats.append(("DISTANCIA", f"{human.distance_traveled:.0f}px", COLOR_TEXT_PRIMARY))
                stats.append(("SCORE", f"{getattr(human, 'score', 0)}", COLOR_TEXT_ACCENT))
            else:
                stats.append(("ROL", "DEPREDADOR", COLOR_HUMAN_PRED))
                stats.append(("CAPTURAS", f"{human.captures}", COLOR_COMBO))
                stats.append(("MEJOR COMBO", f"x{human.best_combo}", COLOR_COMBO))
                stats.append(("SCORE", f"{human.score + human.captures * 100}", COLOR_TEXT_ACCENT))

            stats.append(("DIFICULTAD", f"Nivel {self.difficulty_level}", (255, 150, 100)))
            stats.append(("LOGROS", f"{len(self.achievements_unlocked)}", COLOR_ACHIEVEMENT))

            # Panel de stats
            panel_w = 340
            panel_h = len(stats) * 32 + 20
            panel_x = center_x - panel_w // 2
            panel_y = y - 10

            stats_surface = pygame.Surface((panel_w, panel_h), pygame.SRCALPHA)
            stats_surface.fill((20, 25, 35, 200))
            self.screen.blit(stats_surface, (panel_x, panel_y))
            pygame.draw.rect(self.screen, (60, 70, 90), (panel_x, panel_y, panel_w, panel_h), 2, border_radius=8)

            for i, (label, value, color) in enumerate(stats):
                sy = y + i * 32
                label_surf = self.font_bold.render(label, True, COLOR_TEXT_SECONDARY)
                self.screen.blit(label_surf, (panel_x + 20, sy))
                value_surf = self.font_number.render(value, True, color)
                self.screen.blit(value_surf, (panel_x + panel_w - 20 - value_surf.get_width(), sy - 4))

            y = panel_y + panel_h + 20

        # Rating (5 estrellas si victoria por música)
        if self.music_victory:
            rating = 5
        else:
            rating = self._calculate_rating()
        stars = "★" * rating + "☆" * (5 - rating)
        star_font = pygame.font.SysFont("Arial", 36, bold=True)
        star_surf = star_font.render(stars, True, (255, 200, 50))
        self.screen.blit(star_surf, (center_x - star_surf.get_width()//2, y))
        y += 50

        # Instrucciones
        sub_text = self.font.render("Pulsa R para Reiniciar  |  ESC para Menú", True, (200, 200, 200))
        self.screen.blit(sub_text, (center_x - sub_text.get_width()//2, y))

    def _calculate_rating(self):
        """Calcula rating de 1-5 estrellas basado en rendimiento."""
        human = self.get_human_entity()
        if not human:
            return 1

        if self.human_role == "PREY":
            if self.time_elapsed >= 100: return 5
            if self.time_elapsed >= 80: return 4
            if self.time_elapsed >= 60: return 3
            if self.time_elapsed >= 30: return 2
            return 1
        else:
            total = human.captures
            if total >= 15: return 5
            if total >= 10: return 4
            if total >= 6: return 3
            if total >= 3: return 2
            return 1

    async def run(self):
        running = True
        while running:
            dt = self.clock.tick(FPS) / 1000.0
            keys = pygame.key.get_pressed()
            mouse_pos = pygame.mouse.get_pos()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                # NUEVO: Evento de fin de música → victoria automática
                elif event.type == self.SONG_END:
                    print("[AUDIO] ¡La música ha terminado! Victoria automática.")
                    self.music_victory = True
                    self.game_over = True
                    self.log_metrics()
                    self.ai_controller.save_and_train(self.human_role)
                elif event.type in (pygame.KEYDOWN, pygame.MOUSEBUTTONDOWN):
                    if self.mode == "MENU":
                        running = self._handle_menu_input(event)
                    else:
                        if event.type == pygame.KEYDOWN:
                            running = self._handle_game_input(event)

            if self.mode in ["CLASSIC", "ADAPTIVE"]:
                if not self.game_over:
                    self.time_elapsed += dt

                    # NUEVO: Dificultad progresiva
                    self._update_difficulty(dt)

                    # Spawn de alimento
                    self.food_spawn_timer += dt
                    if self.food_spawn_timer >= FOOD_SPAWN_RATE:
                        self.food_spawn_timer = 0.0
                        self._spawn_food(1)

                    self.food_list = [f for f in self.food_list if f.alive]

                    human = self.get_human_entity()
                    targets = self.predators if self.human_role == "PREY" else self.preys
                    self.ai_controller.record(human, targets, self.human_role, dt)

                    self._update_entities(dt, keys)
                    self._check_food_collision()
                    self._check_breeding()
                    self._check_collisions()
                    self._check_proximity_alerts(dt)
                    self._check_achievements()
                    self._check_game_over()

                all_entities = self.preys + self.predators
                effective_dt = self.visual_manager.update(dt, all_entities)

                self._draw_game()

            elif self.mode == "MENU":
                self.menu_time += dt
                self._spawn_menu_particles(dt)
                self._update_menu_particles(dt)

                for btn in self.menu_buttons:
                    btn.update(mouse_pos, dt)

                self.draw_menu()
            self.dashboard.draw(self.screen)
            pygame.display.flip()

            await asyncio.sleep(0)

        #generate_reports()
        pygame.quit()