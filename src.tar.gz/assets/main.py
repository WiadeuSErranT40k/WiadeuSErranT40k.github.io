import pygame
import asyncio
from game_manager import GameManager
async def main():
    juego = GameManager()
    await juego.run()

if __name__ == "__main__":
    asyncio.run(main())