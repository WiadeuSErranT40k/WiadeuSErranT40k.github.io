import asyncio
from game import Game

async def main():
    app = Game()
    await app.run()

if __name__ == "__main__":
    asyncio.run(main())