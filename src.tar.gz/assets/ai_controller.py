"""Controlador de IA: recolección de datos, k-NN en Python Puro para WebAssembly."""

import math
from datetime import datetime
from config import *
from utils import distancia_toroidal, save_web_data, load_web_data


class PureKNN:
    """Implementación ligera de k-NN compatible con WebAssembly."""
    
    def __init__(self, k=5):
        self.k = k
        self.dataset = []
        
    def fit(self, data):
        self.dataset = data
        
    def predict(self, features):
        if not self.dataset:
            return 0  # Comportamiento por defecto si no hay datos
            
        distances = []
        for row in self.dataset:
            # Distancia Euclidiana en el espacio de 3 dimensiones (features)
            db_features = row['features']
            dist = math.sqrt(
                (features[0] - db_features[0])**2 + 
                (features[1] - db_features[1])**2 + 
                (features[2] - db_features[2])**2
            )
            distances.append((dist, row['action']))
            
        # Ordenar por distancia (los más cercanos primero)
        distances.sort(key=lambda x: x[0])
        
        # Obtener los 'k' vecinos más cercanos
        top_k_actions = [x[1] for x in distances[:self.k]]
        
        # Retornar la moda (la acción más repetida)
        return max(set(top_k_actions), key=top_k_actions.count)


class AIController:
    """Maneja la recolección de datos y el entrenamiento k-NN nativo."""

    def __init__(self, cross_role_training=False):
        self.data_buffer = []
        self.record_timer = 0.0
        self.cross_role_training = cross_role_training
        
        # Nombres de las claves en localStorage
        self.key_prey = "apex_dataset_prey"
        self.key_pred = "apex_dataset_pred"

        # Modelos activos en memoria
        self.model_prey = PureKNN(k=5)
        self.model_pred = PureKNN(k=5)
        
        # Cargar datos existentes al iniciar
        self._load_existing_models()

    def _load_existing_models(self):
        """Carga los datasets guardados en el navegador a los modelos k-NN."""
        data_prey = load_web_data(self.key_prey)
        if data_prey:
            self.model_prey.fit(data_prey)
            print(f"[AI] Modelo PREY cargado con {len(data_prey)} muestras.")
            
        data_pred = load_web_data(self.key_pred)
        if data_pred:
            self.model_pred.fit(data_pred)
            print(f"[AI] Modelo PREDATOR cargado con {len(data_pred)} muestras.")

    def record(self, human, targets, role, dt):
        """Registra una muestra de comportamiento humano."""
        self.record_timer += dt
        if self.record_timer < 0.2:
            return
        self.record_timer = 0.0

        if not targets or not human:
            return

        alive_targets = [p for p in targets if p.alive] if role == "PREDATOR" else targets
        if not alive_targets:
            return

        closest = min(alive_targets, key=lambda p: distancia_toroidal(
            p.pos[0], p.pos[1], human.pos[0], human.pos[1]))
        dist = distancia_toroidal(closest.pos[0], closest.pos[1], human.pos[0], human.pos[1])
        
        # Normalizamos los datos ligeramente para que las magnitudes no rompan el k-NN
        # dist suele ser grande (0-1000), stamina es (0-1). Dividimos dist para equilibrar el peso.
        norm_dist = dist / 100.0 
        
        self.data_buffer.append({
            'features': [norm_dist, human.stamina, closest.stamina],
            'action': 1 if human.is_sprinting else 0
        })

    def save_and_train(self, role):
        """Guarda dataset en localStorage y actualiza el modelo en RAM."""
        if not self.data_buffer:
            return

        # Determinar a qué modelo va el entrenamiento
        if self.cross_role_training:
            target_role = "PREDATOR" if role == "PREY" else "PREY"
        else:
            target_role = role

        storage_key = self.key_prey if target_role == "PREY" else self.key_pred
        active_model = self.model_prey if target_role == "PREY" else self.model_pred

        # Cargar historial web, agregar buffer, y guardar
        dataset = load_web_data(storage_key)
        if not isinstance(dataset, list):
            dataset = []
            
        dataset.extend(self.data_buffer)
        save_web_data(dataset, storage_key)
        
        # Actualizar el modelo k-NN en RAM
        active_model.fit(dataset)
        self.data_buffer = []

        print(f"[AI] Modelo k-NN Web actualizado para {target_role}. Total muestras: {len(dataset)}")