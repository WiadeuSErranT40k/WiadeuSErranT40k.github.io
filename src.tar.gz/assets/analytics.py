"""Módulo de analíticas renderizado nativamente en Pygame."""

import pygame
from config import WORLD_W, WORLD_H
from utils import load_web_data

class AnalyticsDashboard:
    def __init__(self):
        self.show_dashboard = False
        self.font_title = pygame.font.SysFont("Arial", 22, bold=True)
        self.font_label = pygame.font.SysFont("Arial", 14)
        
    def toggle(self):
        """Activa o desactiva la visualización del dashboard."""
        self.show_dashboard = not self.show_dashboard

    def draw(self, screen):
        if not self.show_dashboard:
            return

        historial = load_web_data()
        if not historial:
            return

        # 1. Crear fondo semi-transparente (Overlay)
        overlay = pygame.Surface((WORLD_W, WORLD_H), pygame.SRCALPHA)
        overlay.fill((15, 20, 30, 230))
        screen.blit(overlay, (0, 0))

        # 2. Configurar la caja del gráfico principal (Puntuación Histórica)
        margin_x = 80
        margin_y = 120
        graph_w = WORLD_W - (margin_x * 2)
        graph_h = WORLD_H - (margin_y * 2)

        # Título central
        title = self.font_title.render("RENDIMIENTO HISTÓRICO (SCORE)", True, (255, 200, 80))
        screen.blit(title, (WORLD_W // 2 - title.get_width() // 2, 50))

        # Dibujar ejes X e Y
        pygame.draw.line(screen, (100, 110, 130), (margin_x, margin_y), (margin_x, margin_y + graph_h), 2)
        pygame.draw.line(screen, (100, 110, 130), (margin_x, margin_y + graph_h), (margin_x + graph_w, margin_y + graph_h), 2)

        # 3. Extraer y procesar datos
        scores = [float(p.get("Puntuacion", 0)) for p in historial]
        roles = [p.get("Rol_Humano", "PREY") for p in historial]
        
        if not scores:
            no_data = self.font_label.render("No hay suficientes datos para graficar.", True, (150, 150, 150))
            screen.blit(no_data, (WORLD_W // 2 - no_data.get_width() // 2, WORLD_H // 2))
            return

        max_score = max(scores) if max(scores) > 0 else 1
        n_points = len(scores)

        # 4. Calcular coordenadas de los puntos
        points = []
        for i, score in enumerate(scores):
            # Normalizar a la escala del gráfico
            px = margin_x + (i * (graph_w / max(1, n_points - 1))) if n_points > 1 else margin_x + graph_w // 2
            py = margin_y + graph_h - ((score / max_score) * graph_h)
            points.append((px, py))

        # 5. Dibujar la línea que conecta los puntos
        if len(points) > 1:
            pygame.draw.lines(screen, (100, 200, 255), False, points, 2)

        # 6. Dibujar los nodos (puntos) con colores según el rol
        for i, (px, py) in enumerate(points):
            color = (50, 255, 50) if roles[i] == "PREY" else (255, 50, 50)
            pygame.draw.circle(screen, color, (int(px), int(py)), 6)
            
            # Al hacer hover con el mouse, mostrar el valor exacto
            mx, my = pygame.mouse.get_pos()
            if abs(mx - px) < 8 and abs(my - py) < 8:
                val_text = self.font_label.render(str(int(scores[i])), True, (255, 255, 255))
                screen.blit(val_text, (px - val_text.get_width() // 2, py - 25))

        # 7. Etiquetas de los ejes
        max_label = self.font_label.render(str(int(max_score)), True, (200, 200, 200))
        screen.blit(max_label, (margin_x - max_label.get_width() - 10, margin_y - 10))
        
        min_label = self.font_label.render("0", True, (200, 200, 200))
        screen.blit(min_label, (margin_x - min_label.get_width() - 10, margin_y + graph_h - 10))

        # Hint para salir
        hint = self.font_label.render("Pulsa [G] para cerrar las analíticas", True, (150, 160, 180))
        screen.blit(hint, (WORLD_W // 2 - hint.get_width() // 2, WORLD_H - 40))