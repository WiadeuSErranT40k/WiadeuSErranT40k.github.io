import math
import os
import sys
import json
from config import WORLD_W, WORLD_H

def distancia_toroidal(x1, y1, x2, y2, w=WORLD_W, h=WORLD_H):
    dx = abs(x2 - x1)
    dy = abs(y2 - y1)
    dx = min(dx, w - dx)
    dy = min(dy, h - dy)
    return math.hypot(dx, dy)

def direccion_toroidal(x1, y1, x2, y2, w=WORLD_W, h=WORLD_H):
    dx = x2 - x1
    dy = y2 - y1
    if dx > w / 2: dx -= w
    elif dx < -w / 2: dx += w
    if dy > h / 2: dy -= h
    elif dy < -h / 2: dy += h
    return dx, dy

def save_web_data(data, key="apex_metrics"):
    """Guarda métricas. Blindado contra bloqueos de seguridad del navegador."""
    data_str = json.dumps(data)
    
    if sys.platform == "emscripten":
        try:
            import platform
            platform.window.localStorage.setItem(key, data_str)
        except Exception as e:
            print(f"[Web Warning] No se pudo guardar en localStorage: {e}")
    else:
        os.makedirs("saves", exist_ok=True)
        with open(f"saves/{key}.json", "w", encoding="utf-8") as f:
            f.write(data_str)

def load_web_data(key="apex_metrics"):
    """Carga métricas. Blindado contra bloqueos de seguridad del navegador."""
    if sys.platform == "emscripten":
        try:
            import platform
            saved = platform.window.localStorage.getItem(key)
            if saved:
                return json.loads(saved)
        except Exception as e:
            print(f"[Web Warning] No se pudo leer localStorage: {e}")
            return []
    else:
        try:
            with open(f"saves/{key}.json", "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return []