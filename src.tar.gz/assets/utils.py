import random

def get_random_color():
    """Genera un color RGB aleatorio."""
    return (random.randint(50, 255), random.randint(50, 255), random.randint(50, 255))