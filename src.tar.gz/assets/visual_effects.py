"""Sistema de efectos visuales: partículas, trails, capturas, alimento, reproducción,
screen shake, slow motion, alertas de proximidad, combos, ondas de impacto."""

import math
import random
import pygame
from config import *


class Particle:
    def __init__(self, x, y, color, speed_range=(20, 80), size_range=(1, 3), lifetime=PARTICLE_LIFETIME):
        self.pos = [x, y]
        angle = random.uniform(0, 2 * math.pi)
        speed = random.uniform(*speed_range)
        self.vel = [math.cos(angle) * speed, math.sin(angle) * speed]
        self.color = color
        self.size = random.uniform(*size_range)
        self.lifetime = lifetime
        self.age = 0.0
        self.alive = True

    def update(self, dt):
        self.age += dt
        if self.age >= self.lifetime:
            self.alive = False
            return
        self.pos[0] += self.vel[0] * dt
        self.pos[1] += self.vel[1] * dt
        self.vel[0] *= 0.95
        self.vel[1] *= 0.95

    def draw(self, screen):
        if not self.alive:
            return
        alpha = 1.0 - (self.age / self.lifetime)
        size = max(1, int(self.size * alpha))
        color = tuple(int(c * alpha) for c in self.color)
        pygame.draw.circle(screen, color, (int(self.pos[0]), int(self.pos[1])), size)


class Trail:
    def __init__(self, max_length=TRAIL_LENGTH):
        self.positions = []
        self.max_length = max_length

    def add(self, x, y):
        self.positions.append((x, y))
        if len(self.positions) > self.max_length:
            self.positions.pop(0)

    def draw(self, screen, color, radius):
        if len(self.positions) < 2:
            return
        for i, (x, y) in enumerate(self.positions):
            alpha = (i + 1) / len(self.positions)
            size = max(1, int(radius * alpha * 0.6))
            trail_color = tuple(int(c * alpha * 0.5) for c in color)
            pygame.draw.circle(screen, trail_color, (int(x), int(y)), size)


class CaptureEffect:
    def __init__(self, x, y):
        self.pos = [x, y]
        self.radius = 5
        self.max_radius = 40
        self.lifetime = 0.5
        self.age = 0.0
        self.alive = True

    def update(self, dt):
        self.age += dt
        if self.age >= self.lifetime:
            self.alive = False
            return
        progress = self.age / self.lifetime
        self.radius = 5 + (self.max_radius - 5) * progress

    def draw(self, screen):
        if not self.alive:
            return
        alpha = 1.0 - (self.age / self.lifetime)
        color = tuple(int(c * alpha) for c in COLOR_CAPTURE_FLASH)
        width = max(1, int(3 * alpha))
        pygame.draw.circle(screen, color, (int(self.pos[0]), int(self.pos[1])), int(self.radius), width)


class ImpactWave:
    """Onda de impacto que se expande desde un punto."""
    def __init__(self, x, y, color, max_radius=60, lifetime=0.4):
        self.pos = [x, y]
        self.radius = 5
        self.max_radius = max_radius
        self.lifetime = lifetime
        self.age = 0.0
        self.color = color
        self.alive = True

    def update(self, dt):
        self.age += dt
        if self.age >= self.lifetime:
            self.alive = False
            return
        progress = self.age / self.lifetime
        self.radius = 5 + (self.max_radius - 5) * progress

    def draw(self, screen):
        if not self.alive:
            return
        alpha = 1.0 - (self.age / self.lifetime)
        color = tuple(int(c * alpha) for c in self.color)
        width = max(1, int(4 * alpha))
        pygame.draw.circle(screen, color, (int(self.pos[0]), int(self.pos[1])), int(self.radius), width)


class FloatingText:
    def __init__(self, x, y, text, color, font_size=18, lifetime=1.0, rise_speed=30):
        self.pos = [x, y]
        self.text = text
        self.color = color
        self.font = pygame.font.SysFont("Arial", font_size, bold=True)
        self.lifetime = lifetime
        self.age = 0.0
        self.alive = True
        self.rise_speed = rise_speed

    def update(self, dt):
        self.age += dt
        if self.age >= self.lifetime:
            self.alive = False
            return
        self.pos[1] -= self.rise_speed * dt

    def draw(self, screen):
        if not self.alive:
            return
        alpha = 1.0 - (self.age / self.lifetime)
        color = tuple(int(c * alpha) for c in self.color)
        text_surface = self.font.render(self.text, True, color)
        # Sombra
        shadow = self.font.render(self.text, True, (0, 0, 0))
        screen.blit(shadow, (int(self.pos[0] - text_surface.get_width()/2 + 2), int(self.pos[1] + 2)))
        screen.blit(text_surface, (int(self.pos[0] - text_surface.get_width()/2), int(self.pos[1])))


class ComboText:
    """Texto de combo con escala pulsante."""
    def __init__(self, x, y, combo_count, multiplier):
        self.pos = [x, y]
        self.combo_count = combo_count
        self.multiplier = multiplier
        self.lifetime = 1.2
        self.age = 0.0
        self.alive = True
        self.base_font_size = 20 + min(combo_count * 3, 30)
        self.font = pygame.font.SysFont("Arial", self.base_font_size, bold=True)

    def update(self, dt):
        self.age += dt
        if self.age >= self.lifetime:
            self.alive = False
            return
        self.pos[1] -= 40 * dt

    def draw(self, screen):
        if not self.alive:
            return
        alpha = 1.0 - (self.age / self.lifetime)
        pulse = 1.0 + 0.3 * math.sin(self.age * 15)
        scale = pulse

        text = f"x{self.multiplier:.1f} COMBO!"
        color = tuple(int(c * alpha) for c in COLOR_COMBO)

        # Dibujar con outline
        text_surface = self.font.render(text, True, color)
        # Outline negro
        for dx, dy in [(-1,0),(1,0),(0,-1),(0,1)]:
            outline = self.font.render(text, True, (0,0,0))
            screen.blit(outline, (int(self.pos[0] - text_surface.get_width()/2 + dx), int(self.pos[1] + dy)))
        screen.blit(text_surface, (int(self.pos[0] - text_surface.get_width()/2), int(self.pos[1])))


class AchievementPopup:
    """Popup de logro que aparece desde la derecha."""
    def __init__(self, text, color=COLOR_ACHIEVEMENT):
        self.text = text
        self.color = color
        self.font = pygame.font.SysFont("Arial", 16, bold=True)
        self.lifetime = 2.5
        self.age = 0.0
        self.alive = True
        self.target_x = WORLD_W - 20
        self.x = WORLD_W + 200
        self.y = 80
        self.text_surface = self.font.render(text, True, color)
        self.width = self.text_surface.get_width() + 30
        self.height = 36

    def update(self, dt):
        self.age += dt
        if self.age >= self.lifetime:
            self.alive = False
            return
        # Slide in
        if self.age < 0.3:
            progress = self.age / 0.3
            self.x = (WORLD_W + 200) - (220 * progress)
        # Slide out
        elif self.age > self.lifetime - 0.3:
            progress = (self.age - (self.lifetime - 0.3)) / 0.3
            self.x = (WORLD_W - 20) + (220 * progress)
        else:
            self.x = WORLD_W - 20

    def draw(self, screen):
        if not self.alive:
            return
        alpha = 1.0
        if self.age < 0.2:
            alpha = self.age / 0.2
        elif self.age > self.lifetime - 0.3:
            alpha = 1.0 - (self.age - (self.lifetime - 0.3)) / 0.3

        panel_surface = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        bg_color = (25, 30, 40, int(200 * alpha))
        border_color = (*self.color, int(180 * alpha))
        pygame.draw.rect(panel_surface, bg_color, (0, 0, self.width, self.height), border_radius=6)
        pygame.draw.rect(panel_surface, border_color, (0, 0, self.width, self.height), 2, border_radius=6)
        screen.blit(panel_surface, (int(self.x - self.width), self.y))

        text_color = tuple(int(c * alpha) for c in self.color)
        text_surf = self.font.render(self.text, True, text_color)
        screen.blit(text_surf, (int(self.x - self.width + 15), self.y + 10))


class ProximityAlert:
    """Alerta sutil en el borde de la pantalla o como indicador minimalista."""
    def __init__(self, x, y, radius, is_danger=True):
        self.pos = [x, y]
        self.radius = radius
        self.is_danger = is_danger
        self.lifetime = 0.8
        self.age = 0.0
        self.alive = True
        self.color = COLOR_DANGER_ZONE if is_danger else COLOR_SAFE_ZONE

    def update(self, dt):
        self.age += dt
        if self.age >= self.lifetime:
            self.alive = False
            return

    def draw(self, screen):
        if not self.alive:
            return
        progress = self.age / self.lifetime
        alpha = max(0, 1.0 - progress)

        x, y = int(self.pos[0]), int(self.pos[1])

        # Solo dibujar un pequeño indicador de flecha/dirección en el borde
        # NO dibujar círculo grande que obstruya
        pulse = 1.0 + 0.15 * math.sin(self.age * 12)
        arrow_size = int(6 * pulse)

        # Color muy transparente
        color = tuple(int(c * alpha * 0.6) for c in self.color)

        # Dibujar solo 4 pequeños triángulos en las esquinas del radio
        # como indicadores direccionales sutiles
        offsets = [
            (self.radius, 0),      # derecha
            (-self.radius, 0),     # izquierda
            (0, self.radius),      # abajo
            (0, -self.radius),     # arriba
        ]

        for ox, oy in offsets:
            px = x + ox
            py = y + oy
            # Pequeño círculo indicador
            pygame.draw.circle(screen, color, (int(px), int(py)), arrow_size)
            # Brillo central
            glow = tuple(min(255, c + 40) for c in color)
            pygame.draw.circle(screen, glow, (int(px), int(py)), max(1, arrow_size - 2))


class ScreenShake:
    """Efecto de vibración de cámara."""
    def __init__(self, intensity=SHAKE_INTENSITY, duration=SHAKE_DURATION):
        self.intensity = intensity
        self.duration = duration
        self.age = 0.0
        self.alive = True
        self.offset = [0, 0]

    def update(self, dt):
        self.age += dt
        if self.age >= self.duration:
            self.alive = False
            self.offset = [0, 0]
            return
        decay = 1.0 - (self.age / self.duration)
        self.offset = [
            random.uniform(-self.intensity, self.intensity) * decay,
            random.uniform(-self.intensity, self.intensity) * decay
        ]

    def apply(self, screen):
        if not self.alive:
            return screen
        # Retornar offset para aplicar a todos los dibujados
        return self.offset


class SlowMotion:
    """Controla el slow-motion temporal."""
    def __init__(self):
        self.active = False
        self.timer = 0.0
        self.factor = 1.0

    def trigger(self, duration=SLOWMO_DURATION, factor=SLOWMO_FACTOR):
        self.active = True
        self.timer = duration
        self.factor = factor

    def update(self, dt):
        if not self.active:
            return dt
        self.timer -= dt
        if self.timer <= 0:
            self.active = False
            self.factor = 1.0
            return dt
        # Transición suave al final
        if self.timer < 0.15:
            self.factor = SLOWMO_FACTOR + (1.0 - SLOWMO_FACTOR) * (1.0 - self.timer / 0.15)
        return dt * self.factor

    def get_flash_alpha(self):
        if not self.active:
            return 0
        return int(30 * (1.0 - self.timer / SLOWMO_DURATION))


class VisualManager:
    def __init__(self):
        self.particles = []
        self.capture_effects = []
        self.impact_waves = []
        self.floating_texts = []
        self.combo_texts = []
        self.achievement_popups = []
        self.proximity_alerts = []
        self.trails = {}
        self.particle_timer = 0.0
        self.grid_offset = 0.0
        self.screen_shake = None
        self.slow_motion = SlowMotion()

    def update(self, dt, entities):
        # Aplicar slow motion al dt
        effective_dt = self.slow_motion.update(dt)
        self.grid_offset = (self.grid_offset + GRID_ANIM_SPEED * effective_dt) % GRID_SIZE

        self.particle_timer += effective_dt
        for entity in entities:
            if entity.is_sprinting and entity.alive:
                eid = id(entity)
                if eid not in self.trails:
                    self.trails[eid] = Trail()
                self.trails[eid].add(entity.pos[0], entity.pos[1])

                if self.particle_timer >= PARTICLE_SPAWN_RATE:
                    color = COLOR_PARTICLE_PREY if isinstance(entity, Prey) else COLOR_PARTICLE_PRED
                    self.particles.append(Particle(
                        entity.pos[0] + random.uniform(-5, 5),
                        entity.pos[1] + random.uniform(-5, 5),
                        color,
                        speed_range=(10, 50),
                        size_range=(1, 2)
                    ))
            else:
                eid = id(entity)
                if eid in self.trails:
                    self.trails[eid].positions = []

        if self.particle_timer >= PARTICLE_SPAWN_RATE:
            self.particle_timer = 0.0

        for p in self.particles:
            p.update(effective_dt)
        self.particles = [p for p in self.particles if p.alive]

        for e in self.capture_effects:
            e.update(effective_dt)
        self.capture_effects = [e for e in self.capture_effects if e.alive]

        for w in self.impact_waves:
            w.update(effective_dt)
        self.impact_waves = [w for w in self.impact_waves if w.alive]

        for t in self.floating_texts:
            t.update(effective_dt)
        self.floating_texts = [t for t in self.floating_texts if t.alive]

        for c in self.combo_texts:
            c.update(effective_dt)
        self.combo_texts = [c for c in self.combo_texts if c.alive]

        for a in self.achievement_popups:
            a.update(effective_dt)
        self.achievement_popups = [a for a in self.achievement_popups if a.alive]

        for alert in self.proximity_alerts:
            alert.update(effective_dt)
        self.proximity_alerts = [alert for alert in self.proximity_alerts if alert.alive]

        if self.screen_shake:
            self.screen_shake.update(effective_dt)
            if not self.screen_shake.alive:
                self.screen_shake = None

        return effective_dt

    def spawn_capture(self, x, y, combo_multiplier=1.0):
        self.capture_effects.append(CaptureEffect(x, y))
        text = f"+1 CAPTURA!" if combo_multiplier <= 1.0 else f"+{combo_multiplier:.1f}x CAPTURA!"
        self.floating_texts.append(FloatingText(x, y - 20, text, COLOR_COMBO, font_size=20))
        self.impact_waves.append(ImpactWave(x, y, COLOR_COMBO, max_radius=50))
        self.screen_shake = ScreenShake(intensity=4, duration=0.2)
        self.slow_motion.trigger(duration=0.25, factor=0.4)

    def spawn_death(self, x, y):
        for _ in range(15):
            self.particles.append(Particle(x, y, COLOR_CAPTURE_FLASH, speed_range=(30, 120), size_range=(2, 5), lifetime=0.7))
        self.floating_texts.append(FloatingText(x, y, "¡CAZADO!", (255, 80, 80), font_size=16, lifetime=0.9))
        self.impact_waves.append(ImpactWave(x, y, (255, 80, 80), max_radius=40, lifetime=0.5))
        self.screen_shake = ScreenShake(intensity=6, duration=0.3)

    def spawn_food_collect(self, x, y, food_type=FOOD_TYPE_SPEED):
        color = FOOD_TYPE_COLORS.get(food_type, FOOD_COLOR)
        for _ in range(10):
            self.particles.append(Particle(x, y, color, speed_range=(20, 70), size_range=(2, 4), lifetime=0.6))

        labels = {
            FOOD_TYPE_SPEED: "+VELOCIDAD!",
            FOOD_TYPE_INVINCIBLE: "¡INVENCIBLE!",
            FOOD_TYPE_MAGNET: "+IMÁN!",
            FOOD_TYPE_HEAL: "+STAMINA!",
            FOOD_TYPE_SCORE: "+PUNTOS!",
        }
        self.floating_texts.append(FloatingText(x, y - 15, labels.get(food_type, "+ENERGÍA!"), color, font_size=14, lifetime=0.8))
        self.impact_waves.append(ImpactWave(x, y, color, max_radius=25, lifetime=0.3))

    def spawn_breeding(self, x, y):
        for _ in range(15):
            self.particles.append(Particle(x, y, COLOR_BABY_PREY, speed_range=(15, 50), size_range=(2, 4), lifetime=0.8))
        self.floating_texts.append(FloatingText(x, y - 20, "¡BEBÉ!", COLOR_BABY_PREY, font_size=14, lifetime=1.0))
        self.impact_waves.append(ImpactWave(x, y, COLOR_BABY_PREY, max_radius=30, lifetime=0.4))

    def spawn_combo(self, x, y, combo_count, multiplier):
        self.combo_texts.append(ComboText(x, y - 30, combo_count, multiplier))
        self.impact_waves.append(ImpactWave(x, y, COLOR_COMBO, max_radius=35 + combo_count * 3, lifetime=0.35))

    def spawn_achievement(self, text, color=COLOR_ACHIEVEMENT):
        self.achievement_popups.append(AchievementPopup(text, color))

    def spawn_proximity_alert(self, x, y, radius, is_danger=True):
        # Usar radio más pequeño para no obstruir
        small_radius = min(radius, 35)
        self.proximity_alerts.append(ProximityAlert(x, y, small_radius, is_danger))

    def get_shake_offset(self):
        if self.screen_shake and self.screen_shake.alive:
            return self.screen_shake.offset
        return [0, 0]

    def get_slowmo_flash(self):
        return self.slow_motion.get_flash_alpha()

    def draw_background(self, screen):
        screen.fill(COLOR_BG)

        for y in range(0, WORLD_H + GRID_SIZE, GRID_SIZE):
            offset_y = (y + int(self.grid_offset)) % WORLD_H
            brightness = 0.5 + 0.5 * math.sin(offset_y * 0.02 + self.grid_offset * 0.1)
            color = tuple(int(c * brightness) for c in COLOR_GRID)
            pygame.draw.line(screen, color, (0, offset_y), (WORLD_W, offset_y), 1)

        for x in range(0, WORLD_W + GRID_SIZE, GRID_SIZE):
            offset_x = (x + int(self.grid_offset)) % WORLD_W
            brightness = 0.5 + 0.5 * math.sin(offset_x * 0.02 + self.grid_offset * 0.1)
            color = tuple(int(c * brightness) for c in COLOR_GRID)
            pygame.draw.line(screen, color, (offset_x, 0), (offset_x, WORLD_H), 1)

        pygame.draw.line(screen, COLOR_GRID_BRIGHT, (0, 0), (WORLD_W, 0), 2)
        pygame.draw.line(screen, COLOR_GRID_BRIGHT, (0, WORLD_H-1), (WORLD_W, WORLD_H-1), 2)
        pygame.draw.line(screen, COLOR_GRID_BRIGHT, (0, 0), (0, WORLD_H), 2)
        pygame.draw.line(screen, COLOR_GRID_BRIGHT, (WORLD_W-1, 0), (WORLD_W-1, WORLD_H), 2)

    def draw_trails(self, screen, entities):
        for entity in entities:
            if not entity.alive:
                continue
            eid = id(entity)
            if eid in self.trails and self.trails[eid].positions:
                color = COLOR_TRAIL_PREY if isinstance(entity, Prey) else COLOR_TRAIL_PRED
                radius = PREY_RADIUS if isinstance(entity, Prey) else PRED_SIZE // 2
                self.trails[eid].draw(screen, color, radius)

    def draw_effects(self, screen):
        for p in self.particles:
            p.draw(screen)
        for e in self.capture_effects:
            e.draw(screen)
        for w in self.impact_waves:
            w.draw(screen)
        for t in self.floating_texts:
            t.draw(screen)
        for c in self.combo_texts:
            c.draw(screen)
        for a in self.achievement_popups:
            a.draw(screen)
        for alert in self.proximity_alerts:
            alert.draw(screen)

        # Flash de slow motion
        flash_alpha = self.get_slowmo_flash()
        if flash_alpha > 0:
            flash_surface = pygame.Surface((WORLD_W, WORLD_H), pygame.SRCALPHA)
            flash_surface.fill((255, 255, 255, flash_alpha))
            screen.blit(flash_surface, (0, 0))


from entities import Prey