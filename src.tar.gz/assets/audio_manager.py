"""AudioManager: sistema de sonido y música completo.

Genera efectos de sonido proceduralmente usando pygame.mixer.
No requiere archivos de audio externos.
"""

import math
import random
import os
import struct
import pygame
from config import *


class Synthesizer:
    """Genera ondas de sonido proceduralmente."""

    @staticmethod
    def generate_wave(freq, duration, wave_type='sine', volume=0.5, 
                     attack=0.01, decay=0.1, sustain=0.7, release=0.2):
        """Genera una onda de audio con envolvente ADSR.

        Args:
            freq: Frecuencia en Hz
            duration: Duración en segundos
            wave_type: 'sine', 'square', 'sawtooth', 'triangle', 'noise'
            volume: Volumen base (0.0 - 1.0)
            attack, decay, sustain, release: Parámetros ADSR
        """
        sample_rate = 44100
        num_samples = int(sample_rate * duration)

        # Generar forma de onda base
        samples = []
        for i in range(num_samples):
            t = i / sample_rate
            phase = 2 * math.pi * freq * t

            if wave_type == 'sine':
                sample = math.sin(phase)
            elif wave_type == 'square':
                sample = 1.0 if math.sin(phase) >= 0 else -1.0
            elif wave_type == 'sawtooth':
                sample = 2.0 * (phase / (2 * math.pi) - math.floor(phase / (2 * math.pi) + 0.5))
            elif wave_type == 'triangle':
                sample = 2.0 * abs(2.0 * (phase / (2 * math.pi) - math.floor(phase / (2 * math.pi) + 0.5))) - 1.0
            elif wave_type == 'noise':
                sample = random.uniform(-1.0, 1.0)
            else:
                sample = math.sin(phase)

            samples.append(sample)

        # Aplicar envolvente ADSR
        attack_samples = int(sample_rate * attack)
        decay_samples = int(sample_rate * decay)
        release_samples = int(sample_rate * release)
        sustain_samples = num_samples - attack_samples - decay_samples - release_samples

        envelope = []
        for i in range(num_samples):
            if i < attack_samples:
                env = i / attack_samples if attack_samples > 0 else 1.0
            elif i < attack_samples + decay_samples:
                env = 1.0 - (1.0 - sustain) * ((i - attack_samples) / decay_samples)
            elif i < attack_samples + decay_samples + sustain_samples:
                env = sustain
            else:
                rel_pos = (i - attack_samples - decay_samples - sustain_samples) / release_samples
                env = sustain * (1.0 - rel_pos)
            envelope.append(max(0.0, min(1.0, env)))

        # Aplicar envolvente y convertir a bytes
        final_samples = []
        for s, e in zip(samples, envelope):
            val = int(s * e * volume * 32767)
            val = max(-32768, min(32767, val))
            final_samples.append(val)

        # Convertir a formato stereo (16-bit signed)
        audio_bytes = b''
        for val in final_samples:
            audio_bytes += struct.pack('<hh', val, val)  # Stereo

        return audio_bytes, sample_rate

    @staticmethod
    def create_sound(freq, duration, wave_type='sine', volume=0.5,
                    attack=0.01, decay=0.1, sustain=0.7, release=0.2):
        """Crea un objeto pygame.mixer.Sound proceduralmente."""
        audio_bytes, sample_rate = Synthesizer.generate_wave(
            freq, duration, wave_type, volume, attack, decay, sustain, release
        )

        import io
        # Crear un WAV en memoria
        wav_buffer = io.BytesIO()

        # Header WAV
        wav_buffer.write(b'RIFF')
        wav_buffer.write(struct.pack('<I', 36 + len(audio_bytes)))
        wav_buffer.write(b'WAVE')
        wav_buffer.write(b'fmt ')
        wav_buffer.write(struct.pack('<I', 16))  # Subchunk1Size
        wav_buffer.write(struct.pack('<H', 1))   # AudioFormat (PCM)
        wav_buffer.write(struct.pack('<H', 2))   # NumChannels (Stereo)
        wav_buffer.write(struct.pack('<I', sample_rate))
        wav_buffer.write(struct.pack('<I', sample_rate * 4))  # ByteRate
        wav_buffer.write(struct.pack('<H', 4))   # BlockAlign
        wav_buffer.write(struct.pack('<H', 16))  # BitsPerSample
        wav_buffer.write(b'data')
        wav_buffer.write(struct.pack('<I', len(audio_bytes)))
        wav_buffer.write(audio_bytes)

        wav_buffer.seek(0)
        return pygame.mixer.Sound(file=wav_buffer)


class AudioManager:
    """Gestiona música y efectos de sonido del juego."""

    def __init__(self):
        pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=512)

        # Volúmenes
        self.volume_master = DEFAULT_VOLUME_MASTER
        self.volume_music = DEFAULT_VOLUME_MUSIC
        self.volume_sfx = DEFAULT_VOLUME_SFX

        # Canal de música (stream largo)
        self.music_channel = pygame.mixer.Channel(0)
        self.music_channel.set_volume(self.volume_music * self.volume_master)

        # Canales de SFX - usar solo canales disponibles (pygame asigna 8 por defecto: 0-7)
        # El canal 0 ya lo usamos para música, así que usamos 1-7 (7 canales SFX)
        num_channels = pygame.mixer.get_num_channels()
        self.sfx_channels = []
        for i in range(1, min(num_channels, 8)):
            try:
                self.sfx_channels.append(pygame.mixer.Channel(i))
            except IndexError:
                break
        if not self.sfx_channels:
            # Fallback: si no hay canales disponibles, reservar más
            pygame.mixer.set_num_channels(16)
            self.sfx_channels = [pygame.mixer.Channel(i) for i in range(1, 8)]
        self.next_sfx_channel = 0

        # Generar todos los sonidos proceduralmente
        self._generate_sounds()

        # Estado
        self.music_playing = False
        self.current_music_type = None

        # Precargar música ambiental (loop)
        self._generate_music()

    def _generate_sounds(self):
        """Genera todos los efectos de sonido."""
        print("[Audio] Generando efectos de sonido proceduralmente...")

        self.sounds = {}

        # Captura - sonido satisfactorio, corto y brillante
        self.sounds['capture'] = Synthesizer.create_sound(
            SFX_FREQ_CAPTURE, 0.15, 'square', 0.4,
            attack=0.005, decay=0.05, sustain=0.3, release=0.1
        )

        # Combo - pitch ascendente
        self.sounds['combo'] = Synthesizer.create_sound(
            SFX_FREQ_COMBO, 0.2, 'sawtooth', 0.35,
            attack=0.01, decay=0.08, sustain=0.5, release=0.1
        )

        # Comida - sonido brillante y corto
        self.sounds['food'] = Synthesizer.create_sound(
            SFX_FREQ_FOOD, 0.12, 'sine', 0.4,
            attack=0.005, decay=0.04, sustain=0.2, release=0.07
        )

        # Muerte - sonido grave y descendente
        self.sounds['death'] = Synthesizer.create_sound(
            SFX_FREQ_DEATH, 0.4, 'sawtooth', 0.45,
            attack=0.01, decay=0.15, sustain=0.3, release=0.2
        )

        # Sprint - whoosh corto
        self.sounds['sprint_start'] = Synthesizer.create_sound(
            SFX_FREQ_SPRINT, 0.1, 'noise', 0.15,
            attack=0.01, decay=0.05, sustain=0.1, release=0.04
        )

        # Logro - sonido triunfal
        self.sounds['achievement'] = Synthesizer.create_sound(
            SFX_FREQ_ACHIEVEMENT, 0.5, 'square', 0.35,
            attack=0.01, decay=0.1, sustain=0.6, release=0.3
        )

        # Game Over - sonido grave y largo
        self.sounds['gameover'] = Synthesizer.create_sound(
            SFX_FREQ_GAMEOVER, 0.8, 'sawtooth', 0.4,
            attack=0.05, decay=0.2, sustain=0.4, release=0.4
        )

        # Countdown - beep corto
        self.sounds['countdown'] = Synthesizer.create_sound(
            SFX_FREQ_COUNTDOWN, 0.15, 'sine', 0.35,
            attack=0.005, decay=0.02, sustain=0.8, release=0.05
        )

        # Countdown final - beep más alto y largo
        self.sounds['countdown_go'] = Synthesizer.create_sound(
            SFX_FREQ_COUNTDOWN * 1.5, 0.3, 'square', 0.4,
            attack=0.005, decay=0.05, sustain=0.7, release=0.15
        )

        # Alerta proximidad - beep rápido
        self.sounds['alert'] = Synthesizer.create_sound(
            SFX_FREQ_ALERT, 0.08, 'sine', 0.25,
            attack=0.005, decay=0.02, sustain=0.3, release=0.03
        )

        # Reproducción - sonido mágico
        self.sounds['breeding'] = Synthesizer.create_sound(
            SFX_FREQ_BREEDING, 0.3, 'sine', 0.3,
            attack=0.05, decay=0.1, sustain=0.5, release=0.15
        )

        # Boost - sonido de energía
        self.sounds['boost'] = Synthesizer.create_sound(
            SFX_FREQ_BOOST, 0.2, 'sawtooth', 0.3,
            attack=0.01, decay=0.08, sustain=0.4, release=0.1
        )

        # Invencible - sonido brillante
        self.sounds['invincible'] = Synthesizer.create_sound(
            SFX_FREQ_INVINCIBLE, 0.25, 'sine', 0.25,
            attack=0.02, decay=0.08, sustain=0.5, release=0.1
        )

        # Imán - sonido magnético
        self.sounds['magnet'] = Synthesizer.create_sound(
            SFX_FREQ_MAGNET, 0.2, 'triangle', 0.25,
            attack=0.02, decay=0.06, sustain=0.4, release=0.08
        )

        # Hover botón - muy corto y sutil
        self.sounds['hover'] = Synthesizer.create_sound(
            800, 0.05, 'sine', 0.08,
            attack=0.005, decay=0.01, sustain=0.1, release=0.02
        )

        # Click botón
        self.sounds['click'] = Synthesizer.create_sound(
            600, 0.08, 'square', 0.15,
            attack=0.005, decay=0.02, sustain=0.3, release=0.03
        )

        # Dificultad sube
        self.sounds['levelup'] = Synthesizer.create_sound(
            660, 0.3, 'square', 0.3,
            attack=0.01, decay=0.08, sustain=0.5, release=0.15
        )

        print("[Audio] ✅ Todos los efectos generados exitosamente")

    def _generate_music(self):
        """Genera música ambiental procedural de fondo."""
        print("[Audio] Generando música ambiental...")

        # Música de menú - atmosférica y misteriosa
        self.music_menu = self._create_ambient_music(
            duration=30.0,
            base_freq=110,  # A2
            harmony=[110, 130.81, 164.81, 196.00],  # Am7
            tempo=0.15,
            mood='mysterious'
        )

        # Música de juego - tensa y dinámica
        self.music_game = self._create_ambient_music(
            duration=30.0,
            base_freq=130.81,  # C3
            harmony=[130.81, 155.56, 196.00, 246.94],  # Cm7
            tempo=0.12,
            mood='tense'
        )

        # Música de game over - melancólica
        self.music_gameover = self._create_ambient_music(
            duration=15.0,
            base_freq=82.41,  # E2
            harmony=[82.41, 98.00, 123.47, 146.83],  # Em7
            tempo=0.25,
            mood='sad'
        )

        print("[Audio] ✅ Música ambiental generada")

    def _create_ambient_music(self, duration, base_freq, harmony, tempo, mood='mysterious'):
        """Crea una pista de música ambiental procedural."""
        sample_rate = 44100
        num_samples = int(sample_rate * duration)

        samples = [0.0] * num_samples

        # Capa 1: Drones de fondo (senos muy graves)
        for freq in harmony:
            phase = random.uniform(0, 2 * math.pi)
            for i in range(num_samples):
                t = i / sample_rate
                # LFO muy lento para modulación
                lfo = 1.0 + 0.1 * math.sin(t * 0.5)
                samples[i] += 0.08 * math.sin(2 * math.pi * freq * lfo * t + phase)

        # Capa 2: Notas espaciadas (arppegios lentos)
        note_duration = int(sample_rate * tempo)
        current_note = 0
        for i in range(0, num_samples, note_duration):
            freq = harmony[current_note % len(harmony)]
            # Añadir octava superior para brillo
            freq_high = freq * 2

            for j in range(min(note_duration, num_samples - i)):
                t = j / sample_rate
                # Envolvente suave
                env = math.exp(-t * 3)
                samples[i + j] += 0.05 * math.sin(2 * math.pi * freq_high * t) * env

            current_note += random.choice([1, 1, 2])  # Avance aleatorio

        # Capa 3: Textura de ruido muy sutil (ambiente)
        if mood == 'tense':
            for i in range(num_samples):
                t = i / sample_rate
                # Ruido filtrado 
                noise = random.uniform(-0.5, 0.5) * 0.02
                samples[i] += noise * math.sin(t * 0.3)  # Modulado lentamente

        # Normalizar
        max_val = max(abs(s) for s in samples)
        if max_val > 0:
            samples = [s / max_val * 0.3 for s in samples]

        # Convertir a bytes
        audio_bytes = b''
        for s in samples:
            val = int(s * 32767)
            val = max(-32768, min(32767, val))
            audio_bytes += struct.pack('<hh', val, val)

        # Crear WAV en memoria
        import io
        wav_buffer = io.BytesIO()
        wav_buffer.write(b'RIFF')
        wav_buffer.write(struct.pack('<I', 36 + len(audio_bytes)))
        wav_buffer.write(b'WAVE')
        wav_buffer.write(b'fmt ')
        wav_buffer.write(struct.pack('<I', 16))
        wav_buffer.write(struct.pack('<H', 1))
        wav_buffer.write(struct.pack('<H', 2))
        wav_buffer.write(struct.pack('<I', sample_rate))
        wav_buffer.write(struct.pack('<I', sample_rate * 4))
        wav_buffer.write(struct.pack('<H', 4))
        wav_buffer.write(struct.pack('<H', 16))
        wav_buffer.write(b'data')
        wav_buffer.write(struct.pack('<I', len(audio_bytes)))
        wav_buffer.write(audio_bytes)
        wav_buffer.seek(0)

        return pygame.mixer.Sound(file=wav_buffer)

    def _get_sfx_channel(self):
        """Obtiene el siguiente canal SFX disponible (round-robin)."""
        channel = self.sfx_channels[self.next_sfx_channel]
        self.next_sfx_channel = (self.next_sfx_channel + 1) % len(self.sfx_channels)
        return channel

    def play_sfx(self, sound_name, pitch_variation=0.0):
        """Reproduce un efecto de sonido.

        Args:
            sound_name: Nombre del sonido en self.sounds
            pitch_variation: Variación de pitch (0.0 = sin variación)
        """
        if not AUDIO_ENABLED:
            return

        if sound_name not in self.sounds:
            return

        sound = self.sounds[sound_name]
        channel = self._get_sfx_channel()

        # Aplicar variación de pitch si se solicita
        if pitch_variation > 0:
            variation = random.uniform(1.0 - pitch_variation, 1.0 + pitch_variation)
            channel.set_volume(self.volume_sfx * self.volume_master)
            # pygame no soporta pitch nativo, así que simulamos con volumen
            # En una implementación real usaríamos pygame.mixer.Sound.play con fade
        else:
            channel.set_volume(self.volume_sfx * self.volume_master)

        channel.play(sound)

    def play_music(self, music_type='menu'):
        """Reproduce música de fondo en loop.

        Args:
            music_type: 'menu', 'game', 'gameover'
        """
        if not AUDIO_ENABLED:
            return

        # Detener música actual
        self.stop_music()

        if music_type == 'menu':
            sound = self.music_menu
        elif music_type == 'game':
            sound = self.music_game
        elif music_type == 'gameover':
            sound = self.music_gameover
        else:
            return

        self.music_channel.set_volume(self.volume_music * self.volume_master)
        self.music_channel.play(sound, loops=-1)  # Loop infinito
        self.music_playing = True
        self.current_music_type = music_type

    def stop_music(self):
        """Detiene la música de fondo."""
        if self.music_channel.get_busy():
            self.music_channel.stop()
        self.music_playing = False
        self.current_music_type = None

    def fadeout_music(self, time_ms=1000):
        """Hace fade out de la música."""
        if self.music_channel.get_busy():
            self.music_channel.fadeout(time_ms)
        self.music_playing = False

    def set_volume_master(self, volume):
        """Ajusta el volumen maestro (0.0 - 1.0)."""
        self.volume_master = max(0.0, min(1.0, volume))
        self._update_volumes()

    def set_volume_music(self, volume):
        """Ajusta el volumen de música (0.0 - 1.0)."""
        self.volume_music = max(0.0, min(1.0, volume))
        self._update_volumes()

    def set_volume_sfx(self, volume):
        """Ajusta el volumen de efectos (0.0 - 1.0)."""
        self.volume_sfx = max(0.0, min(1.0, volume))
        self._update_volumes()

    def _update_volumes(self):
        """Actualiza los volúmenes de todos los canales."""
        self.music_channel.set_volume(self.volume_music * self.volume_master)
        for channel in self.sfx_channels:
            channel.set_volume(self.volume_sfx * self.volume_master)

    def play_combo_sound(self, combo_count):
        """Reproduce sonido de combo con pitch creciente."""
        if not AUDIO_ENABLED or combo_count < 2:
            return

        # Pitch aumenta con el combo
        base_freq = SFX_FREQ_COMBO
        pitch_mult = 1.0 + (combo_count - 1) * 0.15
        freq = min(base_freq * pitch_mult, 1200)

        # Generar sonido con pitch modificado
        sound = Synthesizer.create_sound(
            freq, 0.15 + combo_count * 0.02, 'square', 0.35,
            attack=0.005, decay=0.05, sustain=0.5, release=0.1
        )

        channel = self._get_sfx_channel()
        channel.set_volume(self.volume_sfx * self.volume_master)
        channel.play(sound)

    def play_countdown(self, number):
        """Reproduce sonido de countdown.

        Args:
            number: 3, 2, 1, o 0 (para GO)
        """
        if not AUDIO_ENABLED:
            return

        if number == 0:
            self.play_sfx('countdown_go')
        else:
            # Pitch aumenta conforme baja el número
            freq = SFX_FREQ_COUNTDOWN * (1.0 + (3 - number) * 0.2)
            sound = Synthesizer.create_sound(
                freq, 0.15, 'sine', 0.35,
                attack=0.005, decay=0.02, sustain=0.8, release=0.05
            )
            channel = self._get_sfx_channel()
            channel.set_volume(self.volume_sfx * self.volume_master)
            channel.play(sound)

    def toggle_mute(self):
        """Activa/desactiva el mute maestro."""
        if self.volume_master > 0:
            self._previous_master = self.volume_master
            self.set_volume_master(0)
        else:
            self.set_volume_master(getattr(self, '_previous_master', 0.8))

    def cleanup(self):
        """Limpia recursos de audio."""
        self.stop_music()
        for channel in self.sfx_channels:
            try:
                channel.stop()
            except:
                pass