"""Clases de entidades con alimento, boost, reproducción, combos, invencibilidad, magnetismo."""

import math
import random
import pickle
import os
import pygame
from abc import abstractmethod
from config import *
from utils import distancia_toroidal, direccion_toroidal


class Entity:
    """Clase base para todas las entidades del juego."""

    def __init__(self, x, y, color):
        self.pos = [x, y]
        self.vel = [0.0, 0.0]
        self.color = color
        self.stamina = STAMINA_MAX
        self.is_sprinting = False
        self.alive = True
        self.distance_traveled = 0.0
        self.pulse_phase = random.uniform(0, 2 * math.pi)
        self.score = 0  # NUEVO: Sistema de puntuación

    def update_stamina(self, dt):
        if self.is_sprinting and self.stamina > 0:
            self.stamina -= DRAIN_RATE * dt
            if self.stamina <= 0:
                self.stamina, self.is_sprinting = 0, False
        else:
            self.stamina += RECOVER_RATE * dt
            if self.stamina > STAMINA_MAX:
                self.stamina = STAMINA_MAX

    def wrap_around(self):
        if self.pos[0] < 0: self.pos[0] += WORLD_W
        if self.pos[0] > WORLD_W: self.pos[0] -= WORLD_W
        if self.pos[1] < 0: self.pos[1] += WORLD_H
        if self.pos[1] > WORLD_H: self.pos[1] -= WORLD_H

    def _apply_movement(self, left, right, up, down, dt, base_speed):
        dx, dy = 0, 0
        if up: dy -= 1
        if down: dy += 1
        if left: dx -= 1
        if right: dx += 1

        speed = base_speed * (SPRINT_MULTIPLIER if self.is_sprinting else 1.0)
        if dx != 0 or dy != 0:
            length = math.hypot(dx, dy)
            self.vel = [(dx / length) * speed, (dy / length) * speed]
        else:
            self.vel = [0.0, 0.0]
        self._commit_move(dt)

    def _commit_move(self, dt):
        prev_pos = list(self.pos)
        self.pos[0] += self.vel[0] * dt
        self.pos[1] += self.vel[1] * dt
        self.distance_traveled += math.hypot(
            self.pos[0] - prev_pos[0], self.pos[1] - prev_pos[1]
        )
        self.update_stamina(dt)
        self.wrap_around()

    @abstractmethod
    def move_human(self, keys, dt):
        pass

    @abstractmethod
    def move_ai(self, targets, dt, mode, **kwargs):
        pass

    @abstractmethod
    def draw(self, screen, time_elapsed=0):
        pass


class Food:
    """Alimento que las presas pueden recoger, con tipos variados."""

    def __init__(self, x, y, food_type=None):
        self.pos = [x, y]
        self.alive = True
        self.pulse_phase = random.uniform(0, 2 * math.pi)
        # NUEVO: Tipo de alimento
        if food_type is None:
            self.food_type = random.choices(FOOD_TYPE_LIST, weights=FOOD_TYPE_WEIGHTS, k=1)[0]
        else:
            self.food_type = food_type
        self.color = FOOD_TYPE_COLORS.get(self.food_type, FOOD_COLOR)

    def draw(self, screen, time_elapsed=0):
        if not self.alive:
            return
        x, y = int(self.pos[0]), int(self.pos[1])

        # Glow pulsante con color del tipo
        pulse = 1.0 + 0.3 * math.sin(time_elapsed * 5 + self.pulse_phase)
        glow_r = int(FOOD_RADIUS * pulse * 3)
        glow_surface = pygame.Surface((glow_r * 2, glow_r * 2), pygame.SRCALPHA)
        pygame.draw.circle(glow_surface, (*self.color, 50), (glow_r, glow_r), glow_r)
        screen.blit(glow_surface, (x - glow_r, y - glow_r))

        # Bolita central
        pygame.draw.circle(screen, self.color, (x, y), FOOD_RADIUS)
        # Brillo
        pygame.draw.circle(screen, (255, 255, 200), (x - 1, y - 1), max(1, FOOD_RADIUS - 1))

        # NUEVO: Indicador de tipo (pequeño punto central)
        inner_colors = {
            FOOD_TYPE_INVINCIBLE: (255, 255, 255),
            FOOD_TYPE_MAGNET: (255, 255, 255),
            FOOD_TYPE_HEAL: (255, 255, 255),
            FOOD_TYPE_SCORE: (255, 255, 255),
        }
        if self.food_type in inner_colors:
            pygame.draw.circle(screen, inner_colors[self.food_type], (x, y), max(1, FOOD_RADIUS - 2))


class Prey(Entity):
    def __init__(self, x, y, is_human=False, is_baby=False):
        color = COLOR_HUMAN_PREY if is_human else (COLOR_BABY_PREY if is_baby else COLOR_AI_PREY)
        super().__init__(x, y, color)
        self.is_human = is_human
        self.is_baby = is_baby
        self.model = None

        # Boost de alimento
        self.boost_timer = 0.0
        self.has_boost = False

        # NUEVO: Estados especiales
        self.invincible_timer = 0.0
        self.is_invincible = False
        self.magnet_timer = 0.0
        self.has_magnet = False

        # Reproducción
        self.breeding_timer = 0.0
        self.can_breed = False
        self.baby_grow_timer = 0.0

        if not is_human:
            self._load_model(MODEL_PREY_PATH)

    def _load_model(self, path):
        try:
            if os.path.exists(path):
                with open(path, 'rb') as f:
                    loaded = pickle.load(f)
                    # Soporta modelo empaquetado (dict) o modelo directo
                    self.model = loaded['model'] if isinstance(loaded, dict) else loaded
        except Exception as e:
            print(f"[IA] Ignorando modelo de escritorio (incompatible en Web): {path}")
            self.model = None

    def update_boost(self, dt):
        if self.has_boost:
            self.boost_timer -= dt
            if self.boost_timer <= 0:
                self.has_boost = False
                self.boost_timer = 0.0

    def update_invincible(self, dt):
        if self.is_invincible:
            self.invincible_timer -= dt
            if self.invincible_timer <= 0:
                self.is_invincible = False
                self.invincible_timer = 0.0

    def update_magnet(self, dt):
        if self.has_magnet:
            self.magnet_timer -= dt
            if self.magnet_timer <= 0:
                self.has_magnet = False
                self.magnet_timer = 0.0

    def apply_food_boost(self, food_type=FOOD_TYPE_SPEED):
        """Aplica efectos según el tipo de alimento."""
        if food_type == FOOD_TYPE_SPEED:
            self.has_boost = True
            self.boost_timer = FOOD_BOOST_DURATION
            self.stamina = min(STAMINA_MAX, self.stamina + FOOD_STAMINA_RECOVERY)
        elif food_type == FOOD_TYPE_INVINCIBLE:
            self.is_invincible = True
            self.invincible_timer = INVINCIBLE_DURATION
            self.stamina = min(STAMINA_MAX, self.stamina + 0.2)
        elif food_type == FOOD_TYPE_MAGNET:
            self.has_magnet = True
            self.magnet_timer = MAGNET_DURATION
            self.stamina = min(STAMINA_MAX, self.stamina + 0.2)
        elif food_type == FOOD_TYPE_HEAL:
            self.stamina = STAMINA_MAX
        elif food_type == FOOD_TYPE_SCORE:
            self.score += 50
            self.stamina = min(STAMINA_MAX, self.stamina + 0.15)

    def update_breeding(self, dt):
        if self.is_baby:
            self.baby_grow_timer += dt
            if self.baby_grow_timer >= 5.0:
                self.is_baby = False
                self.color = COLOR_AI_PREY
            return

        self.breeding_timer += dt
        if self.breeding_timer >= BREEDING_COOLDOWN and self.stamina >= BREEDING_MIN_STAMINA:
            self.can_breed = True
        else:
            self.can_breed = False

    def move_human(self, keys, dt):
        self.is_sprinting = keys[pygame.K_SPACE] and self.stamina > 0
        left = keys[pygame.K_LEFT] or keys[pygame.K_a]
        right = keys[pygame.K_RIGHT] or keys[pygame.K_d]
        up = keys[pygame.K_UP] or keys[pygame.K_w]
        down = keys[pygame.K_DOWN] or keys[pygame.K_s]

        base_speed = VEL_BASE_PREY * (FOOD_BOOST_MULTIPLIER if self.has_boost else 1.0)
        self._apply_movement(left, right, up, down, dt, base_speed)
        self.update_boost(dt)
        self.update_invincible(dt)
        self.update_magnet(dt)
        self.update_breeding(dt)

    def move_ai(self, predators, dt, mode="CLASSIC", food_list=None, difficulty_bonus=0.0, **kwargs):
        if not predators:
            return

        self.update_boost(dt)
        self.update_invincible(dt)
        self.update_magnet(dt)
        self.update_breeding(dt)

        base_speed = VEL_BASE_PREY * (FOOD_BOOST_MULTIPLIER if self.has_boost else 1.0)
        # NUEVO: Aplicar bonus de dificultad a IA
        base_speed *= (1.0 + difficulty_bonus)

        closest_pred = min(predators, key=lambda p: distancia_toroidal(
            p.pos[0], p.pos[1], self.pos[0], self.pos[1]))

        pred_dist = distancia_toroidal(closest_pred.pos[0], closest_pred.pos[1], self.pos[0], self.pos[1])

        # Prioridad 1: Si depredador está muy cerca, huir
        if pred_dist < SPRINT_DIST_PREY:
            dx, dy = direccion_toroidal(closest_pred.pos[0], closest_pred.pos[1], self.pos[0], self.pos[1])
            self._heuristic_sprint(pred_dist)
            speed = base_speed * (SPRINT_MULTIPLIER if self.is_sprinting else 1.0)
            if pred_dist > 0:
                self.vel = [(dx / pred_dist) * speed, (dy / pred_dist) * speed]
            self._commit_move(dt)
            return

        # Prioridad 2: Si tiene magnet, buscar comida cercana
        if self.has_magnet and food_list:
            alive_food = [f for f in food_list if f.alive]
            if alive_food:
                # Atraer comida cercana
                for food in alive_food:
                    f_dist = distancia_toroidal(self.pos[0], self.pos[1], food.pos[0], food.pos[1])
                    if f_dist < MAGNET_RADIUS and f_dist > 5:
                        dx, dy = direccion_toroidal(food.pos[0], food.pos[1], self.pos[0], self.pos[1])
                        food.pos[0] += (dx / f_dist) * 80 * dt
                        food.pos[1] += (dy / f_dist) * 80 * dt

        # Prioridad 3: Si stamina baja, buscar comida
        if self.stamina < 0.4 and food_list:
            alive_food = [f for f in food_list if f.alive]
            if alive_food:
                closest_food = min(alive_food, key=lambda f: distancia_toroidal(
                    f.pos[0], f.pos[1], self.pos[0], self.pos[1]))
                dx, dy = direccion_toroidal(self.pos[0], self.pos[1], closest_food.pos[0], closest_food.pos[1])
                food_dist = math.hypot(dx, dy)
                speed = base_speed * 1.2
                if food_dist > 0:
                    self.vel = [(dx / food_dist) * speed, (dy / food_dist) * speed]
                self._commit_move(dt)
                return

        # Comportamiento normal: huir del depredador
        dx, dy = direccion_toroidal(closest_pred.pos[0], closest_pred.pos[1], self.pos[0], self.pos[1])
        dist = math.hypot(dx, dy)

        if mode == "ADAPTIVE" and hasattr(self, 'ai_controller') and self.ai_controller.model_prey.dataset:
            # Usar nuestro k-NN puro. Pasamos la distancia normalizada (/100.0) igual que al grabar.
            pred_sprint = self.ai_controller.model_prey.predict([dist / 100.0, self.stamina, closest_pred.stamina])
            self.is_sprinting = (pred_sprint == 1 and self.stamina > 0)
        else:
            self._heuristic_sprint(dist)

        speed = base_speed * (SPRINT_MULTIPLIER if self.is_sprinting else 1.0)
        if dist > 0:
            self.vel = [(dx / dist) * speed, (dy / dist) * speed]
            self._commit_move(dt)

    def _heuristic_sprint(self, dist):
        self.is_sprinting = dist < SPRINT_DIST_PREY and self.stamina > SPRINT_STAMINA_THRESHOLD

    def draw(self, screen, time_elapsed=0):
        if not self.alive:
            return

        radius = PREY_RADIUS + (2 if self.is_human else 0)
        if self.is_baby:
            radius = int(radius * 0.7)

        x, y = int(self.pos[0]), int(self.pos[1])

        # NUEVO: Glow de invencibilidad
        if self.is_invincible:
            pulse = 1.0 + 0.4 * math.sin(time_elapsed * 15)
            glow_r = int(radius * pulse * 3)
            glow_surface = pygame.Surface((glow_r * 2, glow_r * 2), pygame.SRCALPHA)
            pygame.draw.circle(glow_surface, (*COLOR_INVINCIBLE, 60), (glow_r, glow_r), glow_r)
            screen.blit(glow_surface, (x - glow_r, y - glow_r))
            # Escudo visual
            shield_r = radius + 6
            pygame.draw.circle(screen, COLOR_INVINCIBLE, (x, y), shield_r, 2)

        # Glow de magnet
        if self.has_magnet:
            pulse = 1.0 + 0.2 * math.sin(time_elapsed * 8)
            magnet_r = int(MAGNET_RADIUS * 0.3 * pulse)
            magnet_surface = pygame.Surface((magnet_r * 2, magnet_r * 2), pygame.SRCALPHA)
            pygame.draw.circle(magnet_surface, (*COLOR_MAGNET, 20), (magnet_r, magnet_r), magnet_r)
            screen.blit(magnet_surface, (x - magnet_r, y - magnet_r))

        # Glow de boost
        if self.has_boost:
            pulse = 1.0 + 0.3 * math.sin(time_elapsed * 12)
            glow_r = int(radius * pulse * 2.5)
            glow_surface = pygame.Surface((glow_r * 2, glow_r * 2), pygame.SRCALPHA)
            pygame.draw.circle(glow_surface, (*COLOR_BOOST_ACTIVE, 50), (glow_r, glow_r), glow_r)
            screen.blit(glow_surface, (x - glow_r, y - glow_r))

        # Glow normal al sprintar
        if self.is_sprinting:
            pulse = 1.0 + 0.2 * math.sin(time_elapsed * 10 + self.pulse_phase)
            glow_radius = int(radius * pulse * 2)
            glow_surface = pygame.Surface((glow_radius * 2, glow_radius * 2), pygame.SRCALPHA)
            glow_color = (*COLOR_HUMAN_GLOW, 30) if self.is_human else (*COLOR_PARTICLE_PREY, 20)
            pygame.draw.circle(glow_surface, glow_color, (glow_radius, glow_radius), glow_radius)
            screen.blit(glow_surface, (x - glow_radius, y - glow_radius))

        if math.hypot(self.vel[0], self.vel[1]) > 10:
            angle = math.atan2(self.vel[1], self.vel[0])
            arrow_len = radius + 4
            arrow_x = x + math.cos(angle) * arrow_len
            arrow_y = y + math.sin(angle) * arrow_len
            pygame.draw.circle(screen, (255, 255, 255), (int(arrow_x), int(arrow_y)), 2)

        # NUEVO: Parpadeo si invencible
        if self.is_invincible and int(time_elapsed * 15) % 2 == 0:
            draw_color = tuple(min(255, c + 80) for c in self.color)
        else:
            draw_color = self.color

        pygame.draw.circle(screen, draw_color, (x, y), radius)
        pygame.draw.circle(screen, 
                          tuple(min(255, c + 40) for c in draw_color), 
                          (x - 1, y - 1), max(1, radius - 2))

        # Indicadores de estado
        indicator_y = y - radius - 5
        if self.has_boost:
            pygame.draw.circle(screen, COLOR_BOOST_ACTIVE, (x - 4, indicator_y), 2)
        if self.is_invincible:
            pygame.draw.circle(screen, COLOR_INVINCIBLE, (x, indicator_y), 2)
        if self.has_magnet:
            pygame.draw.circle(screen, COLOR_MAGNET, (x + 4, indicator_y), 2)

        # Barra de stamina
        bar_x = x - 12
        bar_y = y - 18
        bar_w = 24
        bar_h = 4

        pygame.draw.rect(screen, (40, 40, 40), (bar_x, bar_y, bar_w, bar_h))
        stamina_w = int(bar_w * self.stamina)
        stamina_color = (255, 200, 50) if self.stamina < 0.3 else COLOR_STAMINA_BAR
        if stamina_w > 0:
            pygame.draw.rect(screen, stamina_color, (bar_x, bar_y, stamina_w, bar_h))
        pygame.draw.rect(screen, (100, 100, 100), (bar_x, bar_y, bar_w, bar_h), 1)

        if self.is_human:
            pygame.draw.circle(screen, COLOR_HUMAN_GLOW, (x, y), radius + 3, 1)


class Predator(Entity):
    def __init__(self, x, y, is_human=False):
        color = COLOR_HUMAN_PRED if is_human else COLOR_AI_PRED
        super().__init__(x, y, color)
        self.is_human = is_human
        self.captures = 0
        self.model = None

        # NUEVO: Sistema de combo
        self.combo_count = 0
        self.combo_timer = 0.0
        self.combo_multiplier = 1.0
        self.best_combo = 0

        if not is_human:
            self._load_model(MODEL_PRED_PATH)

    def _load_model(self, path):
        try:
            if os.path.exists(path):
                with open(path, 'rb') as f:
                    loaded = pickle.load(f)
                    # Soporta modelo empaquetado (dict) o modelo directo
                    self.model = loaded['model'] if isinstance(loaded, dict) else loaded
        except Exception as e:
            print(f"[IA] Ignorando modelo de escritorio (incompatible en Web): {path}")
            self.model = None
            
    def add_capture(self, prey_pos):
        """Registra una captura con sistema de combo."""
        self.captures += 1

        # Sistema de combo
        if self.combo_timer > 0:
            self.combo_count += 1
            self.combo_multiplier = min(COMBO_MAX_MULTIPLIER, 1.0 + self.combo_count * COMBO_MULTIPLIER_STEP)
        else:
            self.combo_count = 1
            self.combo_multiplier = 1.0

        self.combo_timer = COMBO_TIMEOUT
        self.score += int(100 * self.combo_multiplier)

        if self.combo_count > self.best_combo:
            self.best_combo = self.combo_count

        return self.combo_count, self.combo_multiplier

    def update_combo(self, dt):
        if self.combo_timer > 0:
            self.combo_timer -= dt
            if self.combo_timer <= 0:
                self.combo_count = 0
                self.combo_multiplier = 1.0

    def move_human(self, keys, dt):
        self.is_sprinting = keys[pygame.K_SPACE] and self.stamina > 0
        left = keys[pygame.K_LEFT] or keys[pygame.K_a]
        right = keys[pygame.K_RIGHT] or keys[pygame.K_d]
        up = keys[pygame.K_UP] or keys[pygame.K_w]
        down = keys[pygame.K_DOWN] or keys[pygame.K_s]
        self._apply_movement(left, right, up, down, dt, VEL_BASE_PRED)
        self.update_combo(dt)

    def move_ai(self, preys, dt, mode="CLASSIC", difficulty_bonus=0.0, **kwargs):
        alive_preys = [p for p in preys if p.alive]
        if not alive_preys:
            return

        self.update_combo(dt)

        closest = min(alive_preys, key=lambda p: distancia_toroidal(
            p.pos[0], p.pos[1], self.pos[0], self.pos[1]))

        future_x = closest.pos[0] + closest.vel[0] * 0.5
        future_y = closest.pos[1] + closest.vel[1] * 0.5

        dx, dy = direccion_toroidal(self.pos[0], self.pos[1], future_x, future_y)
        dist = math.hypot(dx, dy)

        base_speed = VEL_BASE_PRED * (1.0 + difficulty_bonus)

        if mode == "ADAPTIVE" and hasattr(self, 'ai_controller') and self.ai_controller.model_pred.dataset:
            pred_sprint = self.ai_controller.model_pred.predict([dist / 100.0, closest.stamina, self.stamina])
            self.is_sprinting = (pred_sprint == 1 and self.stamina > 0)
        else:
            self._heuristic_sprint(dist)

        speed = base_speed * (SPRINT_MULTIPLIER if self.is_sprinting else 1.0)
        if dist > 0:
            self.vel = [(dx / dist) * speed, (dy / dist) * speed]
            self._commit_move(dt)

    def _heuristic_sprint(self, dist):
        self.is_sprinting = dist < SPRINT_DIST_PRED and self.stamina > SPRINT_STAMINA_THRESHOLD

    def draw(self, screen, time_elapsed=0):
        x, y = int(self.pos[0]), int(self.pos[1])
        half = PRED_SIZE // 2

        # NUEVO: Glow de combo
        if self.combo_count >= 2:
            combo_pulse = 1.0 + 0.2 * math.sin(time_elapsed * 10)
            combo_glow = int(half * combo_pulse * (1.0 + self.combo_count * 0.15))
            combo_surface = pygame.Surface((combo_glow * 2, combo_glow * 2), pygame.SRCALPHA)
            combo_alpha = min(40, 15 + self.combo_count * 5)
            pygame.draw.rect(combo_surface, (*COLOR_COMBO, combo_alpha), 
                           (0, 0, combo_glow * 2, combo_glow * 2), 
                           border_radius=combo_glow)
            screen.blit(combo_surface, (x - combo_glow, y - combo_glow))

        if self.is_sprinting:
            pulse = 1.0 + 0.15 * math.sin(time_elapsed * 8 + self.pulse_phase)
            glow_size = int(PRED_SIZE * pulse * 1.5)
            glow_surface = pygame.Surface((glow_size * 2, glow_size * 2), pygame.SRCALPHA)
            glow_color = (*COLOR_HUMAN_GLOW, 25) if self.is_human else (*COLOR_PARTICLE_PRED, 20)
            pygame.draw.rect(glow_surface, glow_color, 
                           (0, 0, glow_size * 2, glow_size * 2), 
                           border_radius=glow_size)
            screen.blit(glow_surface, (x - glow_size, y - glow_size))

        rect = pygame.Rect(x - half, y - half, PRED_SIZE, PRED_SIZE)
        pygame.draw.rect(screen, self.color, rect, border_radius=3)

        inner_rect = pygame.Rect(x - half + 2, y - half + 2, PRED_SIZE - 4, PRED_SIZE - 4)
        pygame.draw.rect(screen, 
                        tuple(min(255, c + 30) for c in self.color), 
                        inner_rect, border_radius=2)

        # NUEVO: Indicador de combo en el depredador
        if self.combo_count >= 2:
            combo_font = pygame.font.SysFont("Arial", 10, bold=True)
            combo_text = combo_font.render(f"x{self.combo_multiplier:.1f}", True, COLOR_COMBO)
            screen.blit(combo_text, (x - combo_text.get_width()//2, y - half - 14))

        # Barra de stamina
        bar_x = x - 14
        bar_y = y - 20
        bar_w = 28
        bar_h = 4

        pygame.draw.rect(screen, (40, 40, 40), (bar_x, bar_y, bar_w, bar_h))
        stamina_w = int(bar_w * self.stamina)
        stamina_color = (255, 200, 50) if self.stamina < 0.3 else COLOR_PRED_STAMINA
        if stamina_w > 0:
            pygame.draw.rect(screen, stamina_color, (bar_x, bar_y, stamina_w, bar_h))
        pygame.draw.rect(screen, (100, 100, 100), (bar_x, bar_y, bar_w, bar_h), 1)

        if self.is_human:
            pygame.draw.circle(screen, COLOR_HUMAN_GLOW, (x, y), half + 4, 2)
            pygame.draw.polygon(screen, COLOR_HUMAN_GLOW, [
                (x, y - half - 8),
                (x - 4, y - half - 3),
                (x + 4, y - half - 3)
            ])