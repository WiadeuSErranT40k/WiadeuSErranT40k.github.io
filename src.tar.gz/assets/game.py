import pygame
import asyncio
from player import Player

class Game:
    def __init__(self):
        pygame.init()
        self.width, self.height = 800, 600
        
        # 1. Ventana primero
        self.screen = pygame.display.set_mode((self.width, self.height))
        pygame.display.set_caption("Prueba de Pygbag")
        
        self.clock = pygame.time.Clock()
        
        # 2. FUENTE SEGURA PARA LA WEB (None = fuente por defecto, NO USAR SysFont)
        self.font = pygame.font.Font(None, 40)
        
        # 3. Entidades
        self.player = Player(self.width // 2, self.height // 2)

    async def run(self):
        running = True
        while running:
            dt = self.clock.tick(60) / 1000.0
            keys = pygame.key.get_pressed()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

            # Actualizar
            self.player.move(dt, keys, self.width, self.height)

            # Dibujar
            self.screen.fill((30, 35, 45))  # Fondo gris oscuro
            self.player.draw(self.screen)
            
            # Texto
            text = self.font.render("¡Pygbag funciona! Mueve el cuadro con WASD.", True, (255, 255, 200))
            self.screen.blit(text, (20, 20))

            pygame.display.flip()
            
            # CRÍTICO PARA LA WEB: Ceder el control al navegador
            await asyncio.sleep(0)
            
        pygame.quit()